"""Pass 2 checker: rules.md s6 as rewritten (I1-I8, I11). Shares no code with engine.py.
Reads: rows = one per footprint slot (tag or None, cable id, pair, cabinet, cioc, baseplate, slot),
the TQ list (tag, code), the cables (signals, sizes, fields) and the rule dict; for a revision the same of Rev A.
"""
import re
from fractions import Fraction
from math import ceil, floor

BLOCKING = ("D09", "D19", "C01", "C02", "R01")


def _en(rules, typ):
    return [r for r in rules["rules"] if r["type"] == typ and r.get("enabled", True)]


def _cap(rules):
    c = _en(rules, "capacity")[0]
    return c["slots_per_baseplate"], c["baseplates_per_cioc"], c["ciocs_per_cabinet"], c.get("max_cabinets")


def _t(v):
    return "" if v is None else str(v).strip()


def _sigval(cable, pair, sig, field):
    if field in ("tag", "io_type"): return sig[field]
    if field == "cable": return cable["id"]
    if field == "pair": return pair
    if field == "cable_size": return cable["size"]
    if field in (sig.get("extra") or {}): return sig["extra"][field]
    if field in ("group", "segregation"): return cable.get(field) or ""
    return (cable.get("extra") or {}).get(field, "")


def _cval(cable, field):
    """cable field per allocation.md s3; several values -> the sorted tuple (should never be placed)"""
    vals = sorted({_t(_sigval(cable, p, s, field)) for p, s in cable["pairs"].items()} - {""})
    return "" if not vals else vals[0] if len(vals) == 1 else tuple(vals)


def _sel(conds, cable):
    for c in conds:
        v = _cval(cable, c["field"]); v = v.lower() if isinstance(v, str) else "|".join(v).lower()
        op = c["op"]; x = c.get("value")
        if v == "":
            if op not in ("blank", "ne", "not_in"): return False
            continue
        if op == "blank": return False
        if op == "not_blank": continue
        if op == "regex":
            if not re.search(_t(x), v, re.I): return False
            continue
        if op in ("in", "not_in"):
            hit = v in [_t(i).lower() for i in x]
            if hit != (op == "in"): return False
            continue
        y = _t(x).lower()
        good = {"eq": v == y, "ne": v != y, "contains": y in v, "startswith": v.startswith(y)}[op]
        if not good: return False
    return True


def _side(rule, cable):
    v = _cval(cable, rule.get("field", "segregation"))
    if v == "": return "<blank side>" if rule.get("blank_is_value", False) else None
    sets = rule.get("sets")
    if sets is None: return ("v", v)
    for i, st in enumerate(sets):
        if v in [_t(x) for x in st]: return ("set", i)
    return None


def _key(rule, cable):
    fields = rule.get("fields", ["group", "segregation"])
    aw = rule.get("applies_when", [{"field": fields[0], "op": "not_blank"}])
    if not _sel(aw, cable): return None
    return tuple(_cval(cable, f) for f in fields)


def _group(rules, cable):
    g = _en(rules, "grouping")
    if not g: return ""
    return _cval(cable, g[0].get("field", "group"))


def _cont(level, row):
    return {"cabinet": row[3:4], "cioc": row[3:5], "baseplate": row[3:6]}[level]


def check_I1(cables, rows, tq):
    v = []; addr = {}; blocked = {}
    for r in rows:
        if r[0] is not None: addr[r[0]] = addr.get(r[0], 0) + 1
    for t in tq:
        if t[1] in BLOCKING: blocked[t[0]] = blocked.get(t[0], 0) + 1
    known = set()
    for cable in cables:
        for sig in cable["pairs"].values():
            tag = sig["tag"]; known.add(tag)
            a = addr.get(tag, 0); b = 1 if blocked.get(tag, 0) else 0
            if a + b != 1: v.append(f"{tag}: {a} address rows, blocking TQ {'yes' if b else 'no'}")
    for tag in addr:
        if tag not in known: v.append(f"{tag} has a row but is not an input signal")
    return v


def check_I2(rows):
    v = []; seen = {}
    for r in rows:
        if r[3:] in seen: v.append(f"cable {r[1]} pair {r[2]} and cable {seen[r[3:]][1]} pair {seen[r[3:]][2]} share {r[3:]}")
        seen[r[3:]] = r
    return v


def check_I3(rows, rules):
    S, P, K, mx = _cap(rules); v = []
    for r in rows:
        c, k, b, s = r[3:]
        if not (1 <= s <= S and 1 <= b <= P and 1 <= k <= K and c >= 1 and (mx is None or c <= mx)):
            v.append(f"cable {r[1]} pair {r[2]} out of bounds {(c, k, b, s)}")
    return v


def check_I4(cables, rows, rules):
    S, P, K, mx = _cap(rules); v = []
    by = {}
    for r in rows: by.setdefault(r[1], []).append(r)
    for cable in cables:
        cid = cable["id"]; rs = by.get(cid)
        if not rs: continue
        if len({r[3:5] for r in rs}) != 1: v.append(f"cable {cid}: rows in more than one CIOC"); continue
        if len(rs) != cable["size"] or sorted(r[2] for r in rs) != list(range(1, cable["size"] + 1)):
            v.append(f"cable {cid}: {len(rs)} rows for size {cable['size']}"); continue
        pos = {r[2]: (r[5] - 1) * S + (r[6] - 1) for r in rs}
        if any(pos[p] != pos[1] + p - 1 for p in pos): v.append(f"cable {cid}: rows not consecutive in pair order")
        if cable["size"] <= S:
            if len({r[5] for r in rs}) != 1: v.append(f"cable {cid}: small cable in more than one baseplate")
        elif pos[1] % S != 0: v.append(f"cable {cid}: large cable does not start at slot 1")
        tags = {r[2]: r[0] for r in rs}
        want = {p: None for p in range(1, cable["size"] + 1)}
        want.update({p: s["tag"] for p, s in cable["pairs"].items()})
        if tags != want: v.append(f"cable {cid}: not placed whole (signal rows do not match its signals)")
    known = {c["id"] for c in cables}
    for cid in by:
        if cid not in known: v.append(f"rows for unknown cable {cid}")
    return v


def _held(cables, rows, level, fn):
    cab = {c["id"]: c for c in cables}; held = {}
    for cid, cont in sorted({(r[1], _cont(level, r)) for r in rows}):
        held.setdefault(cont, []).append(fn(cab[cid]))
    return held


def check_I5(cables, rows, rules):
    v = []
    for rule in _en(rules, "separate"):
        lvl = rule.get("level", "cioc")
        for cont, xs in sorted(_held(cables, rows, lvl, lambda c: _side(rule, c)).items()):
            sides = {x for x in xs if x is not None}
            if len(sides) > 1: v.append(f"rule {rule['id']}: {lvl} {cont} holds sides {sorted(map(str, sides))}")
    return v


def check_I6(cables, rows, rules):
    v = []
    for rule in _en(rules, "dedicated"):
        lvl = rule.get("level", "cioc")
        for cont, xs in sorted(_held(cables, rows, lvl, lambda c: _key(rule, c)).items()):
            keys = {x for x in xs if x is not None}
            if len(keys) > 1: v.append(f"rule {rule['id']}: {lvl} {cont} holds keys {sorted(map(str, keys))}")
            if not rule.get("allow_guests", True) and keys and any(x is None for x in xs):
                v.append(f"rule {rule['id']}: {lvl} {cont} holds a keyed cable and a guest")
    return v


def _gcabs(cables, rows, rules):
    cab = {c["id"]: c for c in cables}; out = {}
    for cid, c in {(r[1], r[3]) for r in rows}:
        g = _group(rules, cab[cid])
        if g != "": out.setdefault(g, set()).add(c)
    return out


def _nat(s):
    return (tuple((0, int(p), "") if p.isdigit() else (1, 0, p) for p in re.split(r"(\d+)", str(s)) if p), str(s))


def _run(cs):
    return max(cs) - min(cs) + 1 == len(cs)


def check_I7_base(cables, rows, tq, rules, count_blocked=False):
    g = _en(rules, "grouping")
    if not g: return []
    g = g[0]; v = []; cabs = _gcabs(cables, rows, rules)
    for grp, cs in sorted(cabs.items(), key=lambda kv: _nat(kv[0])):
        if not _run(cs): v.append(f"group {grp} is in cabinets {sorted(cs)}")
        if g.get("span", "only_if_too_big") == "never" and len(cs) > 1: v.append(f"span never: group {grp} is in cabinets {sorted(cs)}")
    order = g.get("order", "natural")
    if order in ("natural", "size_desc"):
        if order == "size_desc":
            data_blocked = {t[0] for t in tq if t[1] in ("D09", "D19")}
            sz = {}
            for c in cables:                      # GAP: which cables count toward "total footprint slots of the group"
                if not count_blocked and any(s["tag"] in data_blocked for s in c["pairs"].values()): continue
                gg = _group(rules, c)
                if gg != "": sz[gg] = sz.get(gg, 0) + c["size"]
            seq = sorted(cabs, key=lambda x: (-sz.get(x, 0), _nat(x)))
        else:
            seq = sorted(cabs, key=_nat)
        for a, b in zip(seq, seq[1:]):
            if min(cabs[a]) > min(cabs[b]): v.append(f"order: group {b} starts in {min(cabs[b])}, before group {a} in {min(cabs[a])}")
    return v


def check_I7_rev(cables_a, rows_a, cables_b, rows_b, rules):
    g = _en(rules, "grouping")
    if not g: return []
    never = g[0].get("span", "only_if_too_big") == "never"; v = []
    ga = _gcabs(cables_a, rows_a, rules); gb = _gcabs(cables_b, rows_b, rules)
    for grp in sorted(set(ga) | set(gb), key=_nat):
        a = ga.get(grp, set()); b = gb.get(grp, set())
        if a:
            if not _run(a | b): v.append(f"group {grp}: Rev A cabinets {sorted(a)} with Rev B cabinets {sorted(b)} are not one run")
        elif b and not _run(b): v.append(f"new group {grp} is in cabinets {sorted(b)}")
        if never and len(a) == 1 and len(b) > 1: v.append(f"span never: group {grp} had {sorted(a)}, now has {sorted(b)}")
    return v


def _res(pct, n, rounding):
    x = Fraction(int(pct) * n, 100)
    return ceil(x) if rounding == "up" else floor(x) if rounding == "down" else floor(x + Fraction(1, 2))


def _spare(rows, rules):
    """container -> spare left, plus (N, R, per-cabinet?)"""
    sp = _en(rules, "spare")[0]; S, P, K, mx = _cap(rules)
    percab = sp.get("per", "cabinet") == "cabinet"
    if sp.get("unit", "baseplates") == "baseplates":
        items = {(r[3:6]) for r in rows}; N = K * P if percab else P
    else:
        items = {(r[3:7]) for r in rows}; N = K * P * S if percab else P * S
    used = {}
    for it in items:
        key = it[:1] if percab else it[:2]; used[key] = used.get(key, 0) + 1
    return {k: N - u for k, u in used.items()}, N, _res(sp.get("percent", 10), N, sp.get("rounding", "up")), sp


def check_I8_base(rows, rules):
    if not _en(rules, "spare"): return []
    left, N, R, sp = _spare(rows, rules)
    return [f"{k}: {x} {sp.get('unit', 'baseplates')} spare, reserve {R}" for k, x in sorted(left.items()) if x < R]


def check_I8_rev(rows_a, rows_b, rules):
    """returns (failures, reported). Failures only when revision_uses_spare is off."""
    if not _en(rules, "spare"): return [], []
    la, N, R, sp = _spare(rows_a, rules); lb, _, _, _ = _spare(rows_b, rules)
    out = [f"{k}: {x} spare, reserve {R}, Rev A had {la.get(k, N)}" for k, x in sorted(lb.items()) if x < min(R, la.get(k, N))]
    return ([], out) if sp.get("revision_uses_spare", True) else (out, [])


def _labels(cable, rules):
    return ([_side(r, cable) for r in _en(rules, "separate")], [_key(r, cable) for r in _en(rules, "dedicated")], _group(rules, cable))


def check_I11(cables_a, rows_a, cables_b, rows_b, rules):
    ca = {c["id"]: c for c in cables_a}; cb = {c["id"]: c for c in cables_b}
    addr_a = {r[0]: r[3:] for r in rows_a if r[0] is not None}; addr_b = {r[0]: r[3:] for r in rows_b if r[0] is not None}
    v = []
    for cid, a in ca.items():
        b = cb.get(cid)
        if b is None or a["size"] != b["size"] or _labels(a, rules) != _labels(b, rules): continue
        for pair, sig in a["pairs"].items():
            sb = b["pairs"].get(pair)
            if sb is None or sb["tag"] != sig["tag"]: continue
            if sig["tag"] not in addr_a: continue            # GAP: signals with no Rev A address are skipped
            if addr_b.get(sig["tag"]) != addr_a[sig["tag"]]:
                v.append(f"{sig['tag']} (cable {cid}) {addr_a[sig['tag']]} -> {addr_b.get(sig['tag'])}")
    return v
