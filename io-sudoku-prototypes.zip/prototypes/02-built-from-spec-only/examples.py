"""Pass 2: smallest hand-made cases for what the new text still leaves open."""
import copy, random, time
import engine
from engine import allocate, revise
import checker as ck, gen

_t = [0]
def cab(cid, size, group="", seg="", n=None, **extra):
    pairs = {}
    for p in range(1, (n or size) + 1):
        _t[0] += 1; pairs[p] = {"tag": f"T{_t[0]}", "io_type": "AI"}
    return {"id": cid, "size": size, "group": group, "segregation": seg, "extra": extra, "pairs": pairs}

def rules(K=4, P=8, spare=10, preset="Class", span="only_if_too_big", extra=(), **sp):
    rs = copy.deepcopy(gen.DEFAULT)
    c = gen.rule(rs, "capacity"); c["ciocs_per_cabinet"] = K; c["baseplates_per_cioc"] = P
    s = gen.rule(rs, "spare"); s["percent"] = spare; s.update(sp)
    gen.rule(rs, "groups")["span"] = span
    gen.set_preset(rs, preset); rs["rules"] += list(extra)
    return rs

def where(res):
    return {cid: tuple(x + 1 for x in a) for cid, a in sorted(res["start"].items())}

print("C1  chain: a hole left by Rev B fails I7 (revision form) in Rev C, with nothing changed")
rs = rules(K=1, P=1, spare=0)
a = [cab("X", 12, "G1"), cab("Y", 12, "G1"), cab("Z", 12, "G1")]
ra = allocate(a, rs)
b = [copy.deepcopy(a[0]), copy.deepcopy(a[2])]
rb = revise(ra, b, rs); rc = revise(rb, copy.deepcopy(b), rs)
print("   Rev A", where(ra), "| Rev B", where(rb), "| Rev C", where(rc))
print("   I7 A->B:", ck.check_I7_rev(a, ra["rows"], b, rb["rows"], rs))
print("   I7 B->C:", ck.check_I7_rev(b, rb["rows"], b, rc["rows"], rs))

print("C2  step 5 'may_open only if hi + 1 does not exist yet' against 'hi + 1 unless span is never'")
rs = rules(K=1, P=1, spare=0, span="never")
a = [cab("X", 12, "G1")]; ra = allocate(a, rs)
b = copy.deepcopy(a) + [cab("N", 2, "G1")]
for verb in (True, False):
    engine.STEP5_VERBATIM = verb
    rb = revise(ra, b, rs)
    print(f"   step 5 verbatim={verb}: {where(rb)} unplaced={rb['unplaced']}  I7 -> {ck.check_I7_rev(a, ra['rows'], b, rb['rows'], rs)}")
engine.STEP5_VERBATIM = True

print("D1  first group holds only an oversize cable: attempt B opens a cabinet for zero cables")
rs = rules()
cs = [cab("BIG", 120, "G1"), cab("X", 6, "G2")]
r = allocate(cs, rs)
print("  ", where(r), "unplaced", r["unplaced"], "cabinets", r["cabinets"], "empty", r["empty_cabinets"],
      "(only because the s4 sentence 'closed again at once' is applied; the s7 pseudo-code alone leaves cabinet 1 empty)")

print("G1  new group under span never in a revision: the text of I7 only asks for an unbroken run")
print("    (engine gives one cabinet or R01; the checker as worded would accept two)")

print("E   default rules, 10,000 signals: base, then one revision")
cables, meta = gen.gen_cables(random.Random(7), 10000, n_groups=12)
rs = copy.deepcopy(gen.DEFAULT)
t = time.time(); ra = allocate(cables, rs); ta = time.time() - t
cb, cnt = gen.edit(random.Random(11), cables, meta)
for uses in (True, False):
    gen.rule(rs, "spare")["revision_uses_spare"] = uses
    t = time.time(); rb = revise(ra, cb, rs); tb = time.time() - t
    codes = {}
    for c in rb["unplaced"].values(): codes[c] = codes.get(c, 0) + 1
    A = {r[0]: r[3:] for r in ra["rows"] if r[0]}; B = {r[0]: r[3:] for r in rb["rows"] if r[0]}
    common = [x for x in A if x in B]
    f8, rep8 = ck.check_I8_rev(ra["rows"], rb["rows"], rs)
    bad = {"I7": ck.check_I7_rev(cables, ra["rows"], cb, rb["rows"], rs), "I11": ck.check_I11(cables, ra["rows"], cb, rb["rows"], rs),
           "I5": ck.check_I5(cb, rb["rows"], rs), "I6": ck.check_I6(cb, rb["rows"], rs), "I4": ck.check_I4(cb, rb["rows"], rs), "I8": f8}
    print(f"   base {ta:.3f}s, {ra['cabinets']} cabinets, unplaced {ra['unplaced'] or 'none'}; edits {cnt}")
    print(f"   revision, revision_uses_spare={uses}: {tb:.3f}s, unplaced by code {codes or 'none'}, cables placed in reserve {len(rb['used_spare'])}, "
          f"{sum(1 for x in common if A[x] != B[x])} of {len(common)} common signals moved, cabinets {rb['cabinets']}, violations { {k: len(v) for k, v in bad.items() if v} or 'none'}, I8 reported {len(rep8)}")
