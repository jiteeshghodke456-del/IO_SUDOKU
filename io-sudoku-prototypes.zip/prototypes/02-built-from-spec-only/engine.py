"""Pass 2 engine: the NEW allocation.md (s3, 5, 6, 7, 10) followed literally.
Places where the text still forced a choice are marked GAP(n) and listed in the report.
"""
import re
from fractions import Fraction
import math

GUEST = ("<guest>",)
# GAP switch: step 5 says "may_open only if hi + 1 does not exist yet" and does not mention span never.
# True = step 5 verbatim. False = the "Allowed cabinets" paragraph wins (no hi+1 under never).
STEP5_VERBATIM = True


def natkey(v):
    s = "" if v is None else str(v)
    return (tuple((0, int(p), "") if p.isdigit() else (1, 0, p) for p in re.split(r"(\d+)", s) if p != ""), s)


def norm(v):
    return "" if v is None else str(v).strip()


def sig_field(cable, pair, sig, field):
    if field == "tag": return sig["tag"]
    if field == "io_type": return sig["io_type"]
    if field == "cable": return cable["id"]
    if field == "pair": return pair
    if field == "cable_size": return cable["size"]
    ex = sig.get("extra") or {}
    if field in ex: return ex[field]
    if field in ("group", "segregation"): return cable.get(field) or ""
    return (cable.get("extra") or {}).get(field, "")


def sel_match(conds, get):
    """rules.md s2: text, trimmed, case-insensitive; blank fails all but blank, ne, not_in; empty list matches."""
    for c in conds:
        v = norm(get(c["field"])).lower(); op = c["op"]; x = c.get("value")
        lx = [norm(i).lower() for i in x] if isinstance(x, list) else norm(x).lower()
        if v == "":
            ok = op in ("blank", "ne", "not_in")
        elif op == "eq": ok = v == lx
        elif op == "ne": ok = v != lx
        elif op == "in": ok = v in lx
        elif op == "not_in": ok = v not in lx
        elif op == "contains": ok = lx in v
        elif op == "startswith": ok = v.startswith(lx)
        elif op == "regex": ok = re.search(norm(x), v, re.I) is not None
        elif op == "blank": ok = False
        elif op == "not_blank": ok = True
        else: raise ValueError(op)
        if not ok: return False
    return True


def reserve(percent, n, rounding):
    x = Fraction(int(percent) * n, 100)
    if rounding == "up": return math.ceil(x)
    if rounding == "down": return math.floor(x)
    return math.floor(x + Fraction(1, 2))


class Bp:
    __slots__ = ("slots", "used", "cnt")
    def __init__(self, S): self.slots = [None] * S; self.used = 0; self.cnt = {}


class Cioc:
    __slots__ = ("bps", "used_bps", "fslots", "cnt")
    def __init__(self, S, P): self.bps = [Bp(S) for _ in range(P)]; self.used_bps = 0; self.fslots = 0; self.cnt = {}


class Cab:
    __slots__ = ("ciocs", "used_bps", "fslots", "cnt", "ncables")
    def __init__(self): self.ciocs = []; self.used_bps = 0; self.fslots = 0; self.cnt = {}; self.ncables = 0


class Engine:
    def __init__(self, rules):
        en = [r for r in rules["rules"] if r.get("enabled", True)]
        cap = [r for r in en if r["type"] == "capacity"][0]
        self.S, self.P, self.K = cap["slots_per_baseplate"], cap["baseplates_per_cioc"], cap["ciocs_per_cabinet"]
        self.max_cab = cap.get("max_cabinets")
        g = [r for r in en if r["type"] == "grouping"]
        self.grouping = g[0] if g else None
        sp = [r for r in en if r["type"] == "spare"]
        self.spare = sp[0] if sp else None
        self.preds = []
        for r in en:
            if r["type"] == "separate":
                self.preds.append(dict(id=r["id"], type="separate", level=r.get("level", "cioc"),
                                       field=r.get("field", "segregation"), sets=r.get("sets"),
                                       blank_is_value=r.get("blank_is_value", False)))
            elif r["type"] == "dedicated":
                fields = r.get("fields", ["group", "segregation"])
                self.preds.append(dict(id=r["id"], type="dedicated", level=r.get("level", "cioc"), fields=fields,
                                       applies_when=r.get("applies_when", [{"field": fields[0], "op": "not_blank"}]),
                                       allow_guests=r.get("allow_guests", True)))
        self.lev = {"baseplate": [], "cioc": [], "cabinet": []}
        for i, r in enumerate(self.preds):
            r["ix"] = i; self.lev[r["level"]].append(r)
        self.ded = [r for r in self.preds if r["type"] == "dedicated"]
        self.cabinets = []; self.start = {}; self.size = {}; self.lab = {}; self.group = {}
        self.journal = None; self.why = {}; self.cur = None

    # ---------- s3: cable fields and labels (the job of validate)
    def label(self, cable):
        """returns None, or the blocking data TQ code (D09 / D19)"""
        cid = cable["id"]; sigs = sorted(cable["pairs"].items())
        gfield = self.grouping.get("field", "group") if self.grouping else None
        cache = {}
        def cfield(f):
            if f not in cache:
                vals = {norm(sig_field(cable, p, s, f)) for p, s in sigs} - {""}   # GAP: values compared exactly (case kept)
                cache[f] = None if len(vals) > 1 else (next(iter(vals)) if vals else "")
            return cache[f]
        # first rule in rule-set order with a conflicting field decides the TQ (GAP: D19 vs D09 when both conflict)
        uses = []
        if self.grouping: uses.append((self.grouping.get("field", "group"),))
        for r in self.preds:
            uses.append((r["field"],) if r["type"] == "separate" else tuple(r["fields"]) + tuple(c["field"] for c in r["applies_when"]))
        for fs in uses:
            for f in fs:
                if cfield(f) is None: return "D19" if f == gfield else "D09"
        lab = []
        for r in self.preds:
            if r["type"] == "separate":
                v = cfield(r["field"])
                if v == "": lab.append(("<blank>",) if r["blank_is_value"] else None)
                elif r["sets"] is None: lab.append(v)
                else:
                    side = None
                    for i, st in enumerate(r["sets"]):
                        if v in [norm(x) for x in st]: side = i; break
                    lab.append(side)
            else:
                lab.append(tuple(cfield(f) for f in r["fields"]) if sel_match(r["applies_when"], cfield) else GUEST)
        self.lab[cid] = tuple(lab); self.size[cid] = cable["size"]
        self.group[cid] = (cfield(gfield) or None) if gfield else None
        return None

    def labels_of(self, cid):
        return (self.lab[cid], self.group[cid])

    # ---------- s5
    def accepts(self, cont, level, cid):
        lab = self.lab[cid]
        for r in self.lev[level]:
            l = lab[r["ix"]]; d = cont.cnt.get(r["ix"])
            if not d: continue
            ok = True
            if r["type"] == "separate":
                if l is not None and any(k != l for k in d): ok = False
            elif l == GUEST:
                if not r["allow_guests"] and any(k != GUEST for k in d): ok = False
            else:
                if any(k != GUEST and k != l for k in d): ok = False
                elif not r["allow_guests"] and GUEST in d: ok = False
            if not ok:
                self.why.setdefault(self.cur, set()).add(r["id"]); return False
        return True

    def budget_ok(self, cab, cioc, new_bps, new_slots):
        sp = self.spare
        if sp is None: return True
        S, P, K = self.S, self.P, self.K
        rnd = sp.get("rounding", "up"); pct = sp.get("percent", 10); percab = sp.get("per", "cabinet") == "cabinet"
        if sp.get("unit", "baseplates") == "baseplates":
            N = K * P if percab else P
            used = cab.used_bps if percab else (cioc.used_bps if cioc else 0); new = new_bps
        else:
            N = K * P * S if percab else P * S
            used = cab.fslots if percab else (cioc.fslots if cioc else 0); new = new_slots
        ok = used + new <= N - reserve(pct, N, rnd)
        if not ok: self.why.setdefault(self.cur, set()).add("spare")
        return ok

    # ---------- state
    def _addlab(self, cont, level, cid, d):
        lab = self.lab[cid]
        for r in self.lev[level]:
            l = lab[r["ix"]]
            if l is None: continue
            m = cont.cnt.setdefault(r["ix"], {})
            m[l] = m.get(l, 0) + d
            if m[l] == 0: del m[l]

    def _put(self, cid, c, k, b, s):
        S = self.S; cab = self.cabinets[c]; cioc = cab.ciocs[k]; n = self.size[cid]; p0 = b * S + s
        for bi in range(b, (p0 + n - 1) // S + 1):
            bp = cioc.bps[bi]
            if bp.used == 0: cioc.used_bps += 1; cab.used_bps += 1
            lo = max(p0, bi * S); hi = min(p0 + n, (bi + 1) * S)
            for pos in range(lo, hi):
                assert bp.slots[pos - bi * S] is None
                bp.slots[pos - bi * S] = cid
            bp.used += hi - lo
            self._addlab(bp, "baseplate", cid, 1)
        cioc.fslots += n; cab.fslots += n; cab.ncables += 1
        self._addlab(cioc, "cioc", cid, 1); self._addlab(cab, "cabinet", cid, 1)
        self.start[cid] = (c, k, b, s)
        if self.journal is not None: self.journal.append(("put", cid))

    def _remove(self, cid):
        S = self.S; c, k, b, s = self.start.pop(cid); cab = self.cabinets[c]; cioc = cab.ciocs[k]; n = self.size[cid]
        p0 = b * S + s
        for bi in range(b, (p0 + n - 1) // S + 1):
            bp = cioc.bps[bi]
            lo = max(p0, bi * S); hi = min(p0 + n, (bi + 1) * S)
            for pos in range(lo, hi): bp.slots[pos - bi * S] = None
            bp.used -= hi - lo
            if bp.used == 0: cioc.used_bps -= 1; cab.used_bps -= 1
            self._addlab(bp, "baseplate", cid, -1)
        cioc.fslots -= n; cab.fslots -= n; cab.ncables -= 1
        self._addlab(cioc, "cioc", cid, -1); self._addlab(cab, "cabinet", cid, -1)

    def _open_cioc(self, c):
        self.cabinets[c].ciocs.append(Cioc(self.S, self.P))
        if self.journal is not None: self.journal.append(("cioc", c))

    def _open_cab(self):
        self.cabinets.append(Cab())
        if self.journal is not None: self.journal.append(("cab",))

    def undo(self, journal):
        for e in reversed(journal):
            if e[0] == "put": self._remove(e[1])
            elif e[0] == "cioc": self.cabinets[e[1]].ciocs.pop()
            else: self.cabinets.pop()

    # ---------- s6
    def place_at(self, cid, c, k, b, s, check_budget):
        """c, k, b, s are 0-based here; the text is 1-based"""
        S, P = self.S, self.P; n = self.size[cid]; self.cur = cid
        m = -(-(s + n) // S)
        if c >= len(self.cabinets) or k >= len(self.cabinets[c].ciocs): return False
        if b + m > P: return False
        if n <= S and s + n > S: return False
        if n > S and s != 0: return False
        cab = self.cabinets[c]; cioc = cab.ciocs[k]; p0 = b * S + s; newly = 0
        for bi in range(b, b + m):
            bp = cioc.bps[bi]; lo = max(p0, bi * S); hi = min(p0 + n, (bi + 1) * S)
            if any(bp.slots[pos - bi * S] is not None for pos in range(lo, hi)): return False
        if not self.accepts(cab, "cabinet", cid) or not self.accepts(cioc, "cioc", cid): return False
        for bi in range(b, b + m):
            if not self.accepts(cioc.bps[bi], "baseplate", cid): return False
            if cioc.bps[bi].used == 0: newly += 1
        if check_budget and not self.budget_ok(cab, cioc, newly, n): return False
        self._put(cid, c, k, b, s); return True

    def try_cabinet(self, cid, c, use_spare=False):
        S, P, K = self.S, self.P, self.K; cab = self.cabinets[c]; n = self.size[cid]
        if not self.accepts(cab, "cabinet", cid): return False
        m = -(-n // S)
        if m > P: self.why.setdefault(cid, set()).add("size"); return False
        ok = lambda cioc, nb: use_spare or self.budget_ok(cab, cioc, nb, n)
        for k, cioc in enumerate(cab.ciocs):
            if not self.accepts(cioc, "cioc", cid): continue
            if n <= S:
                for b, bp in enumerate(cioc.bps):
                    if bp.used > 0 and self.accepts(bp, "baseplate", cid):
                        run = 0; at = None
                        for i, v in enumerate(bp.slots):
                            run = run + 1 if v is None else 0
                            if run == n: at = i - n + 1; break
                        if at is not None and ok(cioc, 0):
                            self._put(cid, c, k, b, at); return True
            if ok(cioc, m):
                run = 0
                for b, bp in enumerate(cioc.bps):
                    run = run + 1 if bp.used == 0 else 0
                    if run == m:
                        self._put(cid, c, k, b - m + 1, 0); return True
        if len(cab.ciocs) < K and ok(None, m):
            self._open_cioc(c); self._put(cid, c, len(cab.ciocs) - 1, 0, 0); return True
        return False

    def place(self, cid, cabs, may_open, use_spare=False):
        """returns True or a TQ code (s9)"""
        self.cur = cid
        for c in cabs:
            if self.try_cabinet(cid, c, use_spare): return True
        if may_open:
            if self.max_cab is None or len(self.cabinets) < self.max_cab:
                self._open_cab()
                if self.try_cabinet(cid, len(self.cabinets) - 1, use_spare): return True
                self.cabinets.pop()
                if self.journal is not None: self.journal.pop()
                return "C01"                                   # does not fit an empty cabinet
            self.why.setdefault(cid, set()).add("cabinet limit"); return "C02"
        self.why.setdefault(cid, set()).add("no room"); return "C01"

    # ---------- s7 orders
    def cable_order(self, cids):
        def k(i):
            out = []
            for r in self.ded:
                l = self.lab[i][r["ix"]]
                out.append((1,) if l == GUEST else (0, tuple((v == "", natkey(v)) for v in l)))
            return (tuple(out), -self.size[i], natkey(i))
        return sorted(cids, key=k)

    def group_block(self, cids, current, span, unplaced, use_spare=False):
        """s7 loop body for one group. Returns the new 'current'."""
        S, P = self.S, self.P
        cg = []
        for i in self.cable_order(cids):
            if -(-self.size[i] // S) > P:
                unplaced[i] = "C01"; self.why.setdefault(i, set()).add("size")
            else:
                cg.append(i); unplaced.pop(i, None)
        placed = False
        if span in ("only_if_too_big", "never"):
            if current is not None:                                            # A
                self.journal = []; placed = True
                for i in cg:
                    if self.place(i, [current], False, use_spare) is not True:
                        self.undo(self.journal); placed = False; break
                self.journal = None
            if not placed:                                                     # B
                if self.max_cab is None or len(self.cabinets) < self.max_cab:
                    self.journal = []; self._open_cab(); new = len(self.cabinets) - 1; placed = True
                    for i in cg:
                        if self.place(i, [new], False, use_spare) is not True:
                            self.undo(self.journal); placed = False; break
                    self.journal = None
                    if placed and self.cabinets[new].ncables == 0:
                        self.cabinets.pop()                # s4: a cabinet that receives nothing is closed at once
                else:
                    for i in cg: self.why.setdefault(i, set()).add("cabinet limit")
        if not placed:
            if span == "never":
                for i in cg: unplaced[i] = "R01"
                return current
            for i in cg:
                lo = current if current is not None else 0     # GAP: "[current .. last cabinet]" while current is none
                r = self.place(i, range(lo, len(self.cabinets)), True, use_spare)
                if r is not True: unplaced[i] = r
        used = [self.start[i][0] for i in cg if i in self.start]
        return max(used) if used else current

    def rows(self, cables):
        """one row per footprint slot: (tag or None, cable id, pair, cabinet, cioc, baseplate, slot), 1-based"""
        S = self.S; out = []
        for cable in cables:
            st = self.start.get(cable["id"])
            if st is None: continue
            c, k, b, s = st
            for pair in range(1, cable["size"] + 1):
                pos = b * S + s + pair - 1
                sig = cable["pairs"].get(pair)
                out.append((sig["tag"] if sig else None, cable["id"], pair, c + 1, k + 1, pos // S + 1, pos % S + 1))
        out.sort(key=lambda r: r[3:])
        return out


def _bundle(eng, cables, rules, unplaced):
    tq = []
    for cable in cables:
        if cable["id"] in unplaced:
            for pair, sig in sorted(cable["pairs"].items()): tq.append((sig["tag"], unplaced[cable["id"]]))
    return dict(rows=eng.rows(cables), tq=tq, unplaced=dict(unplaced), cables=cables, rules=rules,
                start=dict(eng.start), structure=[len(c.ciocs) for c in eng.cabinets],
                cabinets=len(eng.cabinets), empty_cabinets=sum(1 for c in eng.cabinets if c.ncables == 0),
                why={k: sorted(v) for k, v in eng.why.items() if k in unplaced})


def allocate(cables, rules):
    eng = Engine(rules)
    cables = sorted(cables, key=lambda c: natkey(c["id"]))
    unplaced = {}; groups = {}; blank = []; gsz = {}
    for cable in cables:
        code = eng.label(cable)
        if code: unplaced[cable["id"]] = code; continue
        g = eng.group[cable["id"]]
        if g is None: blank.append(cable["id"])
        else: groups.setdefault(g, []).append(cable["id"]); gsz[g] = gsz.get(g, 0) + cable["size"]
    gr = eng.grouping or {}
    span = gr.get("span", "only_if_too_big"); order = gr.get("order", "natural"); bl = gr.get("blank", "fill_free_slots")
    if order == "size_desc": gorder = sorted(groups, key=lambda g: (-gsz[g], natkey(g)))   # GAP: which cables count
    else: gorder = sorted(groups, key=natkey)
    current = None
    for g in gorder:
        current = eng.group_block(groups[g], current, span, unplaced)
    for i in sorted(blank, key=lambda i: (-eng.size[i], natkey(i))):
        lo = 0 if bl == "fill_free_slots" or current is None else current
        r = eng.place(i, range(lo, len(eng.cabinets)), True)
        if r is not True: unplaced[i] = r
    return _bundle(eng, cables, rules, unplaced)


def revise(prev, cables_b, rules):
    """s10. prev = the Rev A bundle."""
    ea = Engine(rules)                      # GAP: Rev A labels are recomputed under the Rev B rule set
    a_ok = set(); grp_a = {}
    for cable in prev["cables"]:
        if ea.label(cable) is None: a_ok.add(cable["id"])
    for cid, (c, k, b, s) in prev["start"].items():
        if cid in a_ok and ea.group[cid] is not None: grp_a.setdefault(ea.group[cid], set()).add(c)
    eng = Engine(rules)
    for n in prev["structure"]:             # step 1
        eng.cabinets.append(Cab())
        for _ in range(n): eng.cabinets[-1].ciocs.append(Cioc(eng.S, eng.P))
    cables_b = sorted(cables_b, key=lambda c: natkey(c["id"]))
    unplaced = {}; todo = []; gnow = {}; stable = []; old = prev["start"]

    def note(cid):
        g = eng.group[cid]
        if g is not None: gnow.setdefault(g, set()).add(eng.start[cid][0])

    def allowed(g):
        cs = grp_a.get(g, set()) | gnow.get(g, set())
        return (min(cs), max(cs)) if cs else None

    for cable in cables_b:                  # step 2 (cables_b is already in natural id order)
        cid = cable["id"]; code = eng.label(cable)
        if code: unplaced[cid] = code; continue
        if (cid in old and cid in a_ok and ea.size[cid] == eng.size[cid] and ea.labels_of(cid) == eng.labels_of(cid)
                and eng.place_at(cid, *old[cid], False)):
            note(cid); stable.append(cid)
        else:
            todo.append(cid)
    todo.sort(key=lambda i: (-eng.size[i], natkey(i)))        # step 3
    sp = eng.spare or {}; span = (eng.grouping or {}).get("span", "only_if_too_big")
    used_spare = []

    def one_pass(use_spare):
        for cid in todo:                                      # step 4
            if cid in eng.start or cid not in old: continue
            g = eng.group[cid]; oc = old[cid][0]
            if g is not None:
                al = allowed(g)
                if al is None: continue
                hi = al[1] if span == "never" else al[1] + 1
                if not (al[0] <= oc <= hi): continue
            if eng.place_at(cid, *old[cid], not use_spare):
                note(cid); unplaced.pop(cid, None)
                if use_spare: used_spare.append(cid)
        for cid in todo:                                      # step 5
            if cid in eng.start: continue
            g = eng.group[cid]
            if g is None:
                r = eng.place(cid, range(len(eng.cabinets)), True, use_spare)
            else:
                al = allowed(g)
                if al is None:                                # new group: all its cables together
                    mates = [i for i in todo if i not in eng.start and eng.group[i] == g]
                    cur = len(eng.cabinets) - 1 if eng.cabinets else None
                    eng.group_block(mates, cur, span, unplaced, use_spare)
                    for i in mates:
                        if i in eng.start:
                            note(i)
                            if use_spare: used_spare.append(i)
                    continue
                lo, hi = al
                cabs = list(range(lo, hi + 1)); may_open = False
                if hi + 1 < len(eng.cabinets):
                    if span != "never": cabs.append(hi + 1)
                else:
                    may_open = STEP5_VERBATIM or span != "never"
                r = eng.place(cid, cabs, may_open, use_spare)
            if r is True:
                note(cid); unplaced.pop(cid, None)
                if use_spare: used_spare.append(cid)
            else:
                unplaced[cid] = r

    one_pass(False)
    if sp.get("revision_uses_spare", True) and any(i not in eng.start for i in todo):
        one_pass(True)                                        # step 6
    out = _bundle(eng, cables_b, rules, unplaced); out["stable"] = stable; out["used_spare"] = used_spare
    return out
