"""Pass 2 trials against the rewritten spec. Engine follows the new text literally.
usage: run_trials.py [n_base] [n_rev] [seed]
"""
import sys, time, random, hashlib, json, copy, math
import engine
from engine import allocate, revise
import checker as ck, gen

NB = int(sys.argv[1]) if len(sys.argv) > 1 else 320
NR = int(sys.argv[2]) if len(sys.argv) > 2 else 120
SEED = int(sys.argv[3]) if len(sys.argv) > 3 else 20261011


def check_base(res):
    c, rows, tq, rules = res["cables"], res["rows"], res["tq"], res["rules"]
    return {"I1": ck.check_I1(c, rows, tq), "I2": ck.check_I2(rows), "I3": ck.check_I3(rows, rules),
            "I4": ck.check_I4(c, rows, rules), "I5": ck.check_I5(c, rows, rules), "I6": ck.check_I6(c, rows, rules),
            "I7 (base form)": ck.check_I7_base(c, rows, tq, rules), "I8 (base form)": ck.check_I8_base(rows, rules),
            "  [I7 if the checker also counts D09/D19 cables in group size]": ck.check_I7_base(c, rows, tq, rules, True)}


def check_rev(prev, res):
    c, rows, tq, rules = res["cables"], res["rows"], res["tq"], res["rules"]
    f8, rep8 = ck.check_I8_rev(prev["rows"], rows, rules)
    return {"I1": ck.check_I1(c, rows, tq), "I2": ck.check_I2(rows), "I3": ck.check_I3(rows, rules),
            "I4": ck.check_I4(c, rows, rules), "I5": ck.check_I5(c, rows, rules), "I6": ck.check_I6(c, rows, rules),
            "I7 (revision form)": ck.check_I7_rev(prev["cables"], prev["rows"], c, rows, rules),
            "I8 (revision form, spare off: failed)": f8, "I8 (revision form, spare on: reported only)": rep8,
            "I11": ck.check_I11(prev["cables"], prev["rows"], c, rows, rules)}


def tally(T, mode, v, case):
    t = T.setdefault(mode, {})
    for k, lst in v.items():
        e = t.setdefault(k, [0, None])
        if lst:
            e[0] += 1
            if e[1] is None or case["ncables"] < e[1]["ncables"]: e[1] = dict(case, examples=lst[:3])
    t.setdefault("_n", [0, None])[0] += 1


def summary(rules):
    return [{k: v for k, v in r.items() if k != "enabled" or not v} for r in rules["rules"] if r["type"] not in ("hardware_map", "naming", "cable")]


def show(T, mode):
    t = T.get(mode, {})
    print(f"\n  {mode}: cases with a violation, out of {t.get('_n', [0])[0]}")
    for k, (cnt, ex) in t.items():
        if k != "_n": print(f"    {k:48s} {cnt}")


def add(d, codes):
    for c in codes: d[c] = d.get(c, 0) + 1


def main():
    rng = random.Random(SEED); dig = hashlib.sha256(); T = {}
    unpl = {}; t0 = time.time(); nsig = []; shuf = [0, 0]; ncab = 0; empties = 0
    for i in range(NB):
        n = int(math.exp(rng.uniform(math.log(200), math.log(10000))))
        cables, meta = gen.gen_cables(rng, n); rules = gen.gen_rules(rng)
        res = allocate(cables, rules)
        nsig.append(sum(len(c["pairs"]) for c in cables)); ncab += len(cables)
        tally(T, "BASE", check_base(res), dict(i=i, ncables=len(cables), rules=summary(rules)))
        add(unpl, res["unplaced"].values()); empties += res["empty_cabinets"]
        dig.update(json.dumps(res["rows"]).encode())
        if i % 8 == 0:
            sh = copy.deepcopy(cables); r2 = random.Random(i); r2.shuffle(sh)
            for c in sh:
                items = list(c["pairs"].items()); r2.shuffle(items); c["pairs"] = dict(items)
            shuf[0] += 1; shuf[1] += allocate(sh, rules)["rows"] != res["rows"]
    print(f"BASE: {NB} cases, signals min {min(nsig)} / median {sorted(nsig)[NB // 2]} / max {max(nsig)}, {ncab} cables, {time.time() - t0:.1f}s")
    show(T, "BASE")
    print(f"  unplaced cables by code: {unpl}")
    print(f"  empty cabinets left at the end of a base run: {empties}")
    print(f"  shuffled-input reruns that differed: {shuf[1]} of {shuf[0]}")

    t0 = time.time(); edits = {}; un = {True: {}, False: {}}; moved = [0, 0]; nchain = 0; spare_used = 0; shufr = [0, 0]
    for i in range(NR):
        n = int(math.exp(rng.uniform(math.log(200), math.log(5000))))
        cables, meta = gen.gen_cables(rng, n); rules = gen.gen_rules(rng)
        ra = allocate(cables, rules)
        cb, cnt = gen.edit(rng, cables, meta)
        chain = i % 3 == 0
        if chain: cc, cnt2 = gen.edit(rng, cb, meta); nchain += 1
        for k, x in cnt.items(): edits[k] = edits.get(k, 0) + x
        case = dict(i=i, ncables=len(cb), edits=cnt, rules=summary(rules))
        for verbatim in (True, False):
            engine.STEP5_VERBATIM = verbatim
            tagm = "step 5 verbatim" if verbatim else "step 5 with 'hi+1 unless never'"
            rb = revise(ra, cb, rules)
            tally(T, f"REVISION A->B ({tagm})", check_rev(ra, rb), case)
            add(un[verbatim], rb["unplaced"].values())
            if chain:
                rc = revise(rb, cc, rules)
                tally(T, f"CHAIN B->C ({tagm})", check_rev(rb, rc), dict(case, edits2=cnt2))
            if verbatim:
                dig.update(json.dumps(rb["rows"]).encode()); spare_used += 1 if rb["used_spare"] else 0
                a = {r[0]: r[3:] for r in ra["rows"] if r[0]}; b = {r[0]: r[3:] for r in rb["rows"] if r[0]}
                common = [t for t in a if t in b]; moved[0] += len(common); moved[1] += sum(1 for t in common if a[t] != b[t])
                if i % 8 == 0:
                    sh = copy.deepcopy(cb); random.Random(i).shuffle(sh)
                    shufr[0] += 1; shufr[1] += revise(ra, sh, rules)["rows"] != rb["rows"]
    engine.STEP5_VERBATIM = True
    print(f"\nREVISION: {NR} cases ({nchain} with a second revision B->C), {time.time() - t0:.1f}s, edits A->B in total: {edits}")
    for m in sorted(k for k in T if k != "BASE"): show(T, m)
    print(f"  unplaced cables by code, step 5 verbatim: {un[True]}; with 'unless never': {un[False]}")
    print(f"  cases where pass 3 put at least one cable in the reserve: {spare_used}")
    print(f"  signals placed in both A and B: {moved[0]}, moved: {moved[1]}")
    print(f"  shuffled-input revision reruns that differed: {shufr[1]} of {shufr[0]}")

    print("\nSMALLEST FAILING CASE PER INVARIANT")
    for mode in T:
        for k, (cnt, ex) in T[mode].items():
            if k != "_n" and cnt and "reported only" not in k:
                if k.startswith("  ["): continue
                print(f"  [{mode}] {k}: case {ex['i']}, {ex['ncables']} cables, edits={ex.get('edits')} edits2={ex.get('edits2')}")
                for e in ex["examples"]: print("       ", e)
                print("        rules:", json.dumps(ex["rules"])[:1500])

    print("\nDEFAULT RULE SET, 10,000 signals")
    for groups in (12, 60):
        cables, meta = gen.gen_cables(random.Random(7), 10000, n_groups=groups)
        rules = copy.deepcopy(gen.DEFAULT)
        best = 9
        for _ in range(3):
            t = time.time(); res = allocate(cables, rules); best = min(best, time.time() - t)
        t = time.time(); v = check_base(res); tc = time.time() - t
        codes = {}; add(codes, res["unplaced"].values())
        foot = sum(c["size"] for c in cables)
        print(f"  {sum(len(c['pairs']) for c in cables)} signals, {len(cables)} cables, {groups} groups: engine {best:.3f}s, checker {tc:.3f}s, "
              f"cabinets {res['cabinets']} (lower bound {math.ceil(foot / (28 * 12))}), unplaced by code {codes or 'none'}, "
              f"violations {({k: len(x) for k, x in v.items() if x}) or 'none'}")
    print("\noutput digest:", dig.hexdigest())


if __name__ == "__main__":
    main()
