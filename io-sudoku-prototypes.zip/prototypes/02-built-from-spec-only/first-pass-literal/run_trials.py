"""Random trials: >=300 base cases and >=100 revision cases, in two modes:
fixed   = my best-effort reading (guesses applied where the literal text breaks an invariant)
literal = pseudo-code followed word for word
"""
import sys, time, random, hashlib, json, copy, math
from engine import allocate, revise
import checker as ck, gen

NB = int(sys.argv[1]) if len(sys.argv) > 1 else 300
NR = int(sys.argv[2]) if len(sys.argv) > 2 else 120
SEED = int(sys.argv[3]) if len(sys.argv) > 3 else 20261011


def check_all(cables, rules, res, base_run, rev=None, stable_rows=None):
    rows, tq = res["rows"], res["tq"]; v = {}
    v["I1"] = ck.check_I1(cables, rows, tq)
    v["I2"] = ck.check_I2(rows)
    v["I3"] = ck.check_I3(rows, rules)
    v["I4"] = ck.check_I4(cables, rows, rules)
    v["I5"] = ck.check_I5(cables, rows, rules)
    v["I6"] = ck.check_I6(cables, rows, rules)
    v["I6-guests(not in text)"] = ck.check_I6_guests(cables, rows, rules)
    a, b, c = ck.check_I7(cables, rows, rules, base_run)
    v["I7-unbroken-run"] = a; v["I7-span-never"] = b
    if base_run: v["I7-start-order"] = c
    i8 = ck.check_I8(cables, rows, rules)
    uses = gen.rule(rules, "spare").get("revision_uses_spare", True)
    if rev and uses: v["I8 (reported, not failed)"] = i8
    else: v["I8"] = i8
    if rev:
        ca, ra = rev
        v["I11-as-written"] = ck.check_I11(ca, ra, cables, rows, rules)
        v["I11-plus-same-size"] = ck.check_I11(ca, ra, cables, rows, rules, also_same_size=True)
        if stable_rows is not None:
            a2, b2, _ = ck.check_I7(cables, stable_rows, rules, False)
            v["  (I7 run already broken by untouched cables alone)"] = a2
            v["  (I7 never already broken by untouched cables alone)"] = b2
    return v


def tally(T, mode, v, case):
    t = T.setdefault(mode, {})
    for k, lst in v.items():
        e = t.setdefault(k, [0, None])
        if lst:
            e[0] += 1
            if e[1] is None or case["ncables"] < e[1]["ncables"]:
                e[1] = dict(case, examples=lst[:3])


def summary(rules):
    out = []
    for r in rules["rules"]:
        if r["type"] in ("hardware_map", "naming", "cable"): continue
        out.append({k: v for k, v in r.items() if k not in ("enabled", "type") or (k == "enabled" and not v)} | {"type": r["type"]})
    return out


def show(T, mode, n):
    print(f"\n  mode={mode}: cases with a violation, out of {n}")
    for k, (cnt, ex) in T.get(mode, {}).items():
        print(f"    {k:55s} {cnt}")


def main():
    rng = random.Random(SEED)
    dig = hashlib.sha256()
    T = {}; unpl = {}; t0 = time.time(); nsig_seen = []; shuffle_diff = 0; nshuf = 0; ncab_tot = 0; r01 = [0, 0]; cases_unpl = 0
    for i in range(NB):
        n = int(math.exp(rng.uniform(math.log(200), math.log(10000))))
        cables, meta = gen.gen_cables(rng, n)
        rules = gen.gen_rules(rng, charms=rng.random() < 0.1)
        nsig = sum(len(c["pairs"]) for c in cables); nsig_seen.append(nsig)
        case = dict(i=i, ncables=len(cables), nsig=nsig)
        for mode in ("fixed", "literal"):
            res = allocate(cables, rules, literal=(mode == "literal"))
            v = check_all(cables, rules, res, True)
            tally(T, "base/" + mode, v, dict(case, rules=summary(rules)))
            if mode == "fixed":
                for code in res["unplaced"].values(): unpl[code] = unpl.get(code, 0) + 1
                ncab_tot += len(cables); cases_unpl += 1 if res["unplaced"] else 0
                # R01 groups: would the group fit one cabinet by raw size alone?
                cap = gen.rule(rules, "capacity"); sp = gen.rule(rules, "spare")
                K, P = cap["ciocs_per_cabinet"], cap["baseplates_per_cioc"]
                usable = (K * P - ck._res(sp["percent"], K * P, sp["rounding"])) if sp["per"] == "cabinet" else K * (P - ck._res(sp["percent"], P, sp["rounding"]))
                gs = {}
                for c in cables:
                    if res["unplaced"].get(c["id"]) == "R01": gs[c["group"]] = gs.get(c["group"], 0) + c["size"]
                for g, tot in gs.items(): r01[0 if math.ceil(tot / 12) <= usable else 1] += 1
                dig.update(json.dumps(res["rows"]).encode())
                if i % 10 == 0:                       # row-order independence
                    sh = copy.deepcopy(cables); rng2 = random.Random(i); rng2.shuffle(sh)
                    for c in sh:
                        items = list(c["pairs"].items()); rng2.shuffle(items); c["pairs"] = dict(items)
                    nshuf += 1
                    if allocate(sh, rules)["rows"] != res["rows"]: shuffle_diff += 1
    print(f"BASE: {NB} cases, signals per case min {min(nsig_seen)} / median {sorted(nsig_seen)[NB//2]} / max {max(nsig_seen)}, {time.time()-t0:.1f}s")
    show(T, "base/fixed", NB); show(T, "base/literal", NB)
    print(f"  unplaced cables in base runs (fixed mode), by code: {unpl}; {ncab_tot} cables in total; {cases_unpl} cases had at least one unplaced cable")
    print(f"  R01 groups whose raw size fits one cabinet's usable baseplates: {r01[0]}; R01 groups truly too big: {r01[1]}")
    print(f"  shuffled-input reruns that differed: {shuffle_diff} of {nshuf}")

    unpl_r = {}; t0 = time.time(); edits = {}; moved_tot = [0, 0]
    for i in range(NR):
        n = int(math.exp(rng.uniform(math.log(200), math.log(5000))))
        cables, meta = gen.gen_cables(rng, n)
        rules = gen.gen_rules(rng)
        ra = allocate(cables, rules)
        cb, cnt = gen.edit(rng, cables, meta)
        for k, x in cnt.items(): edits[k] = edits.get(k, 0) + x
        case = dict(i=i, ncables=len(cb), nsig=sum(len(c["pairs"]) for c in cb), edits=cnt)
        for mode in ("fixed", "literal"):
            res = revise(cables, ra["rows"], cb, rules, literal=(mode == "literal"))
            st = set(res["stable"]); tagc = {s["tag"]: c["id"] for c in cb for s in c["pairs"].values()}
            srows = [r for r in res["rows"] if tagc[r[0]] in st]
            v = check_all(cb, rules, res, False, rev=(cables, ra["rows"]), stable_rows=srows)
            tally(T, "rev/" + mode, v, dict(case, rules=summary(rules)))
            if mode == "fixed":
                for code in res["unplaced"].values(): unpl_r[code] = unpl_r.get(code, 0) + 1
                dig.update(json.dumps(res["rows"]).encode())
                a = {r[0]: r[1:] for r in ra["rows"]}; b = {r[0]: r[1:] for r in res["rows"]}
                common = [t for t in a if t in b]
                moved_tot[0] += len(common); moved_tot[1] += sum(1 for t in common if a[t] != b[t])
    print(f"\nREVISION: {NR} cases, {time.time()-t0:.1f}s, edits applied in total: {edits}")
    show(T, "rev/fixed", NR); show(T, "rev/literal", NR)
    print(f"  unplaced cables in revisions (fixed mode), by code: {unpl_r}")
    print(f"  signals placed in both revisions: {moved_tot[0]}, of which moved: {moved_tot[1]}")

    print("\nSMALLEST FAILING CASE PER INVARIANT (fixed mode)")
    for mode in ("base/fixed", "rev/fixed"):
        for k, (cnt, ex) in T.get(mode, {}).items():
            if cnt and not k.startswith("  ("):
                print(f"  [{mode}] {k}: case {ex['i']}, {ex['ncables']} cables, edits={ex.get('edits')}")
                for e in ex["examples"]: print("       ", e)
                print("        rules:", json.dumps(ex["rules"]))

    # timing
    print("\nTIMING")
    for groups in (12, 60):
        r2 = random.Random(7)
        cables, meta = gen.gen_cables(r2, 10000, n_groups=groups)
        for preset in ("Class", "Group", "Any"):
            rules = copy.deepcopy(gen.DEFAULT); gen.set_preset(rules, preset)
            t = time.time(); res = allocate(cables, rules); te = time.time() - t
            t = time.time(); v = check_all(cables, rules, res, True); tc = time.time() - t
            bad = {k: len(x) for k, x in v.items() if x}
            foot = sum(c["size"] for c in cables)
            print(f"  {sum(len(c['pairs']) for c in cables)} signals, {len(cables)} cables, {groups} groups, default rules, preset {preset}: "
                  f"engine {te:.3f}s, checker {tc:.3f}s, cabinets {res['cabinets']} (lower bound {math.ceil(foot/(28*12))}), "
                  f"unplaced {len(res['unplaced'])}, violations {bad or 0}")
    print("\noutput digest:", dig.hexdigest())


if __name__ == "__main__":
    main()
