"""Random cables, rule sets and revision edits."""
import copy, random

DEFAULT = {
  "version": 1, "name": "default-deltav",
  "rules": [
    {"id": "capacity", "type": "capacity", "enabled": True,
     "slots_per_baseplate": 12, "baseplates_per_cioc": 8, "ciocs_per_cabinet": 4, "max_cabinets": None},
    {"id": "cable", "type": "cable", "enabled": True,
     "standard_sizes": [2, 6, 12, 24], "size_when_missing": "infer", "reserve_spare_pairs": {}},
    {"id": "groups", "type": "grouping", "enabled": True,
     "field": "group", "span": "only_if_too_big", "order": "natural", "blank": "fill_free_slots"},
    {"id": "ab", "type": "separate", "enabled": True,
     "level": "cioc", "field": "segregation", "sets": None, "blank_is_value": False},
    {"id": "cioc-sharing", "type": "dedicated", "enabled": True,
     "level": "cioc", "fields": ["group", "segregation"],
     "applies_when": [{"field": "group", "op": "not_blank"}], "allow_guests": True},
    {"id": "spare", "type": "spare", "enabled": True,
     "percent": 10, "unit": "baseplates", "per": "cabinet", "rounding": "up", "revision_uses_spare": True},
    {"id": "hardware", "type": "hardware_map", "enabled": True, "rows": "see docs/spec/domain.md"},
    {"id": "names", "type": "naming", "enabled": True, "area": "AR1", "unit": "100"},
  ],
  "vocab": {},
}
IO = ["AI", "AO", "DI", "DO", "DO-SOV"]


def rule(rs, rid):
    return [r for r in rs["rules"] if r["id"] == rid][0]


def set_preset(rs, preset):
    r = rule(rs, "cioc-sharing")
    if preset == "Class": r["enabled"] = True; r["fields"] = ["group", "segregation"]
    elif preset == "Group": r["enabled"] = True; r["fields"] = ["group"]
    else: r["enabled"] = False


def gen_rules(rng, charms=False):
    rs = copy.deepcopy(DEFAULT)
    cap = rule(rs, "capacity")
    cap["ciocs_per_cabinet"] = rng.choice([3, 4, 6]); cap["baseplates_per_cioc"] = rng.choice([7, 8])
    sp = rule(rs, "spare")
    sp["percent"] = rng.choice([0, 10, 25]); sp["per"] = rng.choice(["cabinet", "cioc"])
    sp["rounding"] = rng.choice(["up", "up", "down", "nearest"])
    sp["revision_uses_spare"] = rng.random() < 0.5
    if charms: sp["unit"] = "charms"
    set_preset(rs, rng.choice(["Class", "Group", "Any"]))
    g = rule(rs, "groups")
    g["span"] = rng.choice(["only_if_too_big", "always", "never"])
    g["blank"] = rng.choice(["fill_free_slots", "place_last"])
    g["order"] = rng.choice(["natural", "natural", "size_desc"])
    for i in range(rng.choice([0, 0, 1, 1, 2, 3])):
        level = rng.choice(["baseplate", "cioc", "cabinet"])
        if rng.random() < 0.5:
            f = rng.choice(["area", "sys", "io_type", "segregation"])
            r = {"id": f"x{i}-sep-{level}-{f}", "type": "separate", "enabled": True, "level": level, "field": f,
                 "sets": None, "blank_is_value": rng.random() < 0.3}
            if f == "io_type": r["sets"] = [["DO-SOV"], ["AI"]]; r["level"] = "baseplate"
            if f == "area" and rng.random() < 0.3: r["sets"] = [["IS"], ["N", "S"]]
        else:
            f = rng.choice(["area", "sys"])
            r = {"id": f"x{i}-ded-{level}-{f}", "type": "dedicated", "enabled": True, "level": level,
                 "fields": rng.choice([[f], ["group", f]]), "allow_guests": rng.random() < 0.6}
            aw = rng.choice(["field", "group", "all", "default", "is"])
            if aw == "field": r["applies_when"] = [{"field": f, "op": "not_blank"}]
            elif aw == "group": r["applies_when"] = [{"field": "group", "op": "not_blank"}]
            elif aw == "all": r["applies_when"] = []
            elif aw == "is": r["applies_when"] = [{"field": "area", "op": "in", "value": ["IS"]}]
        rs["rules"].append(r)
    if rng.random() < 0.05: cap["max_cabinets"] = rng.randint(1, 6)
    return rs


class Tags:
    def __init__(self): self.n = 0
    def new(self): self.n += 1; return f"T-{self.n:06d}"


def new_cable(rng, cid, tags, groups, segs, nonstd, mixed_io):
    size = rng.choice([2, 2, 2, 6, 6, 6, 12, 12, 12, 24, 24])
    if nonstd and rng.random() < 0.10: size = rng.choice([4, 8, 16, 20, 36])
    grp = "" if rng.random() < groups[1] else rng.choice(groups[0])
    n = max(1, rng.randint(size // 2, size))
    if size == 24: n = min(n, 22) if rng.random() < 0.7 else n
    pairs = sorted(rng.sample(range(1, size + 1), n)) if rng.random() < 0.3 else list(range(1, n + 1))
    io = rng.choice(IO)
    c = {"id": cid, "size": size, "group": grp, "segregation": rng.choice(segs),
         "extra": {"area": rng.choice(["", "", "N", "S", "IS"]), "sys": rng.choice(["BPCS", "BPCS", "SIS", ""])},
         "pairs": {}}
    for p in pairs:
        c["pairs"][p] = {"tag": tags.new(), "io_type": rng.choice(IO) if mixed_io and rng.random() < 0.2 else io}
    return c


def gen_cables(rng, n_signals, n_groups=None):
    tags = Tags()
    n_groups = n_groups if n_groups is not None else rng.randint(1, 60)
    names = [f"G{i}" for i in range(1, n_groups + 1)]
    w = [rng.random() ** 2 + 0.02 for _ in names]
    pool = rng.choices(names, weights=w, k=400)
    groups = (pool, rng.choice([0.0, 0.05, 0.15, 0.3]))
    segs = ["A", "B", ""] + (["C"] if rng.random() < 0.25 else [])
    nonstd = rng.random() < 0.4; mixed_io = rng.random() < 0.5; d09 = rng.random() < 0.3
    cables = []; tot = 0; i = 0
    while tot < n_signals:
        i += 1
        c = new_cable(rng, f"CBL-{i}", tags, groups, segs, nonstd, mixed_io)
        if d09 and rng.random() < 0.01 and len(c["pairs"]) > 1:
            p = rng.choice(list(c["pairs"]))
            c["pairs"][p]["extra"] = rng.choice([{"segregation": "B" if c["segregation"] != "B" else "A"},
                                                 {"sys": "SIS" if c["extra"]["sys"] != "SIS" else "BPCS"},
                                                 {"group": "G1" if c["group"] != "G1" else "G2"}])
        cables.append(c); tot += len(c["pairs"])
    if rng.random() < 0.05:
        i += 1
        c = new_cable(rng, f"CBL-{i}", tags, groups, segs, False, False); c["size"] = 120
        cables.append(c)
    return cables, dict(tags=tags, groups=groups, segs=segs, nonstd=nonstd, mixed_io=mixed_io, next=i + 1)


def edit(rng, cables, meta):
    """returns (Rev B cables, counts of edits)"""
    b = copy.deepcopy(cables); tags = meta["tags"]; cnt = {}
    scale = max(1, len(b) // 40)
    def some(k): return rng.sample(b, min(len(b), rng.randint(0, k)))
    for c in some(3 * scale):                                   # signals added on unused pairs
        free = [p for p in range(1, c["size"] + 1) if p not in c["pairs"]]
        for p in rng.sample(free, min(len(free), rng.randint(1, 3))):
            c["pairs"][p] = {"tag": tags.new(), "io_type": next(iter(c["pairs"].values()))["io_type"]}
            cnt["sig_added"] = cnt.get("sig_added", 0) + 1
    for c in some(2 * scale):                                   # signals deleted
        for p in rng.sample(list(c["pairs"]), rng.randint(1, len(c["pairs"]))):
            del c["pairs"][p]; cnt["sig_deleted"] = cnt.get("sig_deleted", 0) + 1
    b = [c for c in b if c["pairs"]]
    for c in some(scale):                                       # cables deleted
        c["pairs"] = {}; cnt["cable_deleted"] = cnt.get("cable_deleted", 0) + 1
    b = [c for c in b if c["pairs"]]
    for c in some(scale):                                       # segregation change
        c["segregation"] = rng.choice([s for s in meta["segs"] if s != c["segregation"]])
        cnt["seg_changed"] = cnt.get("seg_changed", 0) + 1
    for c in some(scale):                                       # group change
        c["group"] = rng.choice(meta["groups"][0] + ["", "GNEW1"]); cnt["group_changed"] = cnt.get("group_changed", 0) + 1
    for c in some(scale):                                       # growth
        bigger = [s for s in [2, 6, 12, 24, 36] if s > c["size"]]
        if bigger: c["size"] = bigger[0]; cnt["grown"] = cnt.get("grown", 0) + 1
    for _ in range(rng.randint(0, 2 * scale)):                  # new cables
        g = (meta["groups"][0] + ["GNEW1", "GNEW2"], meta["groups"][1])
        b.append(new_cable(rng, f"CBL-{meta['next']}", tags, g, meta["segs"], meta["nonstd"], meta["mixed_io"]))
        meta["next"] += 1; cnt["cable_new"] = cnt.get("cable_new", 0) + 1
    return b, cnt
