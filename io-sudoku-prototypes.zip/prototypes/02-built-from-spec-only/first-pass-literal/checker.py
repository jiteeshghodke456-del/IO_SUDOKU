"""Independent checker for I1-I8 and I11 (rules.md s6). Shares no code with engine.py.
Reads only: output rows (tag, cabinet, cioc, baseplate, slot), the TQ list (tag, code),
the input cables and the rule dict. Each function returns a list of violation strings.
"""
import re
from fractions import Fraction
from math import ceil, floor


def _en(rules, typ):
    return [r for r in rules["rules"] if r["type"] == typ and r.get("enabled", True)]


def _cap(rules):
    c = _en(rules, "capacity")[0]
    return c["slots_per_baseplate"], c["baseplates_per_cioc"], c["ciocs_per_cabinet"], c.get("max_cabinets")


def _blank(v):
    return v is None or str(v).strip() == ""


def _val(cable, pair, sig, field):
    if field in ("tag", "io_type"): return sig[field]
    if field == "cable": return cable["id"]
    if field == "pair": return pair
    if field == "cable_size": return cable["size"]
    if field in (sig.get("extra") or {}): return sig["extra"][field]
    if field in ("group", "segregation"): return cable.get(field) or ""
    return (cable.get("extra") or {}).get(field, "")


def _sel(conds, cable, pair, sig):
    for c in conds:
        v = _val(cable, pair, sig, c["field"]); s = "" if v is None else str(v); x = c.get("value"); op = c["op"]
        ok = {"eq": lambda: s == str(x), "ne": lambda: s != str(x),
              "in": lambda: s in [str(i) for i in x], "not_in": lambda: s not in [str(i) for i in x],
              "contains": lambda: str(x) in s, "startswith": lambda: s.startswith(str(x)),
              "regex": lambda: re.search(x, s) is not None,
              "blank": lambda: _blank(v), "not_blank": lambda: not _blank(v)}[op]()
        if not ok: return False
    return True


def _signals(cables):
    """tag -> (cable, pair, sig)"""
    out = {}
    for cable in cables:
        for pair, sig in cable["pairs"].items(): out.setdefault(sig["tag"], []).append((cable, pair, sig))
    return out


def _side(rule, cable, pair, sig):
    v = _val(cable, pair, sig, rule.get("field", "segregation"))
    if _blank(v): return "<blank>" if rule.get("blank_is_value", False) else None
    sets = rule.get("sets")
    if sets is None: return "v:" + str(v)
    for i, st in enumerate(sets):
        if str(v) in [str(x) for x in st]: return i
    return None


def _key(rule, cable, pair, sig):
    aw = rule.get("applies_when", [{"field": "group", "op": "not_blank"}])
    if not _sel(aw, cable, pair, sig): return None
    return tuple("" if _blank(_val(cable, pair, sig, f)) else str(_val(cable, pair, sig, f))
                 for f in rule.get("fields", ["group", "segregation"]))


def _cont(level, row):
    return {"cabinet": row[1:2], "cioc": row[1:3], "baseplate": row[1:4]}[level]


def check_I1(cables, rows, tq):
    v = []; seen = {}
    for r in rows: seen[r[0]] = seen.get(r[0], 0) + 1
    for t in tq: seen[t[0]] = seen.get(t[0], 0) + 1
    inp = _signals(cables)
    for tag, lst in inp.items():
        if len(lst) != 1: v.append(f"input tag {tag} is not unique")
        if seen.get(tag, 0) != 1: v.append(f"{tag} appears {seen.get(tag, 0)} times")
    for tag in seen:
        if tag not in inp: v.append(f"{tag} is in the output but not in the input")
    for t in tq:
        if not t[1]: v.append(f"{t[0]} has a TQ with no reason")
    return v


def check_I2(rows):
    v = []; seen = {}
    for r in rows:
        if r[1:] in seen: v.append(f"{r[0]} and {seen[r[1:]]} share {r[1:]}")
        seen[r[1:]] = r[0]
    return v


def check_I3(rows, rules):
    S, P, K, mx = _cap(rules); v = []
    for tag, c, k, b, s in rows:
        if not (1 <= s <= S and 1 <= b <= P and 1 <= k <= K and c >= 1 and (mx is None or c <= mx)):
            v.append(f"{tag} out of bounds {(c, k, b, s)}")
    return v


def _starts(cables, rows, S):
    """cable id -> (cabinet, cioc, start position in CIOC) from the rows; None if inconsistent"""
    inp = _signals(cables); st = {}; badc = set()
    for tag, c, k, b, s in rows:
        if tag not in inp: continue
        cable, pair, _ = inp[tag][0]
        a = (c, k, (b - 1) * S + (s - 1) - (pair - 1))
        if st.setdefault(cable["id"], a) != a: badc.add(cable["id"])
    return st, badc


def check_I4(cables, rows, rules):
    S, P, K, mx = _cap(rules); v = []
    st, badc = _starts(cables, rows, S)
    placed = {r[0] for r in rows}
    for cid in sorted(badc): v.append(f"cable {cid}: signals not in one CIOC or slot-minus-pair differs")
    owner = {}
    for cable in cables:
        cid = cable["id"]
        n_in = sum(1 for sig in cable["pairs"].values() if sig["tag"] in placed)
        if 0 < n_in < len(cable["pairs"]): v.append(f"cable {cid}: only some of its signals have an address")
        if cid not in st or cid in badc: continue
        c, k, p0 = st[cid]; n = cable["size"]
        if p0 < 0 or p0 + n > P * S: v.append(f"cable {cid}: footprint leaves the CIOC")
        if n <= S:
            if p0 // S != (p0 + n - 1) // S: v.append(f"cable {cid}: small cable crosses a baseplate edge")
        elif p0 % S != 0: v.append(f"cable {cid}: large cable does not start at slot 1")
        for pos in range(p0, p0 + n):
            o = owner.setdefault((c, k, pos), cid)
            if o != cid: v.append(f"cables {cid} and {o}: footprints overlap at {(c, k, pos // S + 1, pos % S + 1)}"); break
    return v


def _two(cables, rows, rules, typ, fn):
    v = []; inp = _signals(cables)
    for rule in _en(rules, typ):
        held = {}
        for row in rows:
            if row[0] not in inp: continue
            cable, pair, sig = inp[row[0]][0]
            x = fn(rule, cable, pair, sig)
            if x is not None: held.setdefault(_cont(rule.get("level", "cioc"), row), set()).add(x)
        for cont, xs in sorted(held.items()):
            if len(xs) > 1: v.append(f"rule {rule['id']}: {rule.get('level', 'cioc')} {cont} holds {sorted(map(str, xs))}")
    return v


def check_I5(cables, rows, rules):
    return _two(cables, rows, rules, "separate", _side)


def check_I6(cables, rows, rules):
    return _two(cables, rows, rules, "dedicated", _key)


def check_I6_guests(cables, rows, rules):
    """Not in the I6 text: allow_guests=false and a container mixes guests with keyed signals."""
    v = []; inp = _signals(cables)
    for rule in _en(rules, "dedicated"):
        if rule.get("allow_guests", True): continue
        held = {}
        for row in rows:
            cable, pair, sig = inp[row[0]][0]
            held.setdefault(_cont(rule.get("level", "cioc"), row), set()).add(_key(rule, cable, pair, sig) is None)
        for cont, xs in sorted(held.items()):
            if len(xs) > 1: v.append(f"rule {rule['id']}: {cont} mixes guests and keyed")
    return v


def _nat(s):
    return (tuple((0, int(p), "") if p.isdigit() else (1, 0, p) for p in re.split(r"(\d+)", str(s)) if p), str(s))


def check_I7(cables, rows, rules, base_run):
    """returns (contiguity violations, span-never violations, start-order violations)"""
    g = _en(rules, "grouping")
    if not g: return [], [], []
    g = g[0]; field = g.get("field", "group"); inp = _signals(cables)
    cabs = {}
    for row in rows:
        cable, pair, sig = inp[row[0]][0]
        val = _val(cable, pair, sig, field)
        if not _blank(val): cabs.setdefault(str(val), set()).add(row[1])
    v1, v2, v3 = [], [], []
    for grp, cs in sorted(cabs.items()):
        if max(cs) - min(cs) + 1 != len(cs): v1.append(f"group {grp} is in cabinets {sorted(cs)}")
        if g.get("span") == "never" and len(cs) > 1: v2.append(f"span never: group {grp} is in cabinets {sorted(cs)}")
    if base_run:
        if g.get("order", "natural") == "size_desc":
            sz = {}
            for cable in cables:
                pair, sig = next(iter(cable["pairs"].items()))
                val = _val(cable, pair, sig, field)
                if not _blank(val): sz[str(val)] = sz.get(str(val), 0) + cable["size"]
            order = sorted(cabs, key=lambda x: (-sz[x], _nat(x)))
        else:
            order = sorted(cabs, key=_nat)
        for a, b in zip(order, order[1:]):
            if min(cabs[a]) > min(cabs[b]): v3.append(f"group {b} starts in cabinet {min(cabs[b])} before group {a} ({min(cabs[a])})")
    return v1, v2, v3


def _res(pct, n, rounding):
    x = Fraction(str(pct)) * n / 100
    return ceil(x) if rounding == "up" else floor(x) if rounding == "down" else floor(x + Fraction(1, 2))


def check_I8(cables, rows, rules):
    sp = _en(rules, "spare")
    if not sp: return []
    sp = sp[0]; S, P, K, mx = _cap(rules); v = []
    st, _ = _starts(cables, rows, S); size = {c["id"]: c["size"] for c in cables}
    used = {}; slots = {}
    for cid, (c, k, p0) in st.items():
        for b in range(p0 // S, (p0 + size[cid] - 1) // S + 1): used.setdefault((c, k), set()).add(b)
        slots[(c, k)] = slots.get((c, k), 0) + size[cid]
    percab = sp.get("per", "cabinet") == "cabinet"; rnd = sp.get("rounding", "up"); pct = sp.get("percent", 10)
    if sp.get("unit", "baseplates") == "baseplates":
        tot = {}
        for (c, k), bs in used.items():
            key = (c,) if percab else (c, k); tot[key] = tot.get(key, 0) + len(bs)
        n = K * P if percab else P
    else:
        tot = {}
        for (c, k), x in slots.items():
            key = (c,) if percab else (c, k); tot[key] = tot.get(key, 0) + x
        n = K * P * S if percab else P * S
    for key, x in sorted(tot.items()):
        if n - x < _res(pct, n, rnd): v.append(f"{key}: {n - x} {sp.get('unit', 'baseplates')} spare, {_res(pct, n, rnd)} reserved")
    return v


def _cable_labels(cable, rules):
    out = []
    for r in _en(rules, "separate"):
        out.append(frozenset(_side(r, cable, p, s) for p, s in cable["pairs"].items()) - {None})
    for r in _en(rules, "dedicated"):
        out.append(frozenset(_key(r, cable, p, s) for p, s in cable["pairs"].items()))
    for r in _en(rules, "grouping"):
        out.append(frozenset("" if _blank(_val(cable, p, s, r.get("field", "group"))) else str(_val(cable, p, s, r.get("field", "group")))
                             for p, s in cable["pairs"].items()))
    return out


def check_I11(cables_a, rows_a, cables_b, rows_b, rules, also_same_size=False):
    """literal text: cable, pair and labels unchanged -> same address. also_same_size adds 'and cable size unchanged'."""
    a = _signals(cables_a); b = _signals(cables_b)
    addr_a = {r[0]: r[1:] for r in rows_a}; addr_b = {r[0]: r[1:] for r in rows_b}
    lab_a = {c["id"]: (_cable_labels(c, rules), c["size"]) for c in cables_a}
    lab_b = {c["id"]: (_cable_labels(c, rules), c["size"]) for c in cables_b}
    v = []
    for tag, lst in a.items():
        if tag not in b or tag not in addr_a: continue        # GUESS: only signals that had an address in Rev A
        ca, pa, _ = lst[0]; cb, pb, _ = b[tag][0]
        if ca["id"] != cb["id"] or pa != pb: continue
        if lab_a[ca["id"]][0] != lab_b[cb["id"]][0]: continue
        if also_same_size and lab_a[ca["id"]][1] != lab_b[cb["id"]][1]: continue
        if addr_b.get(tag) != addr_a[tag]: v.append(f"{tag} (cable {ca['id']}) {addr_a[tag]} -> {addr_b.get(tag)}")
    return v
