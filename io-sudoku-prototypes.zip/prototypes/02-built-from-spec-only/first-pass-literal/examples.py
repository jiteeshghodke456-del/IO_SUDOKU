"""Smallest hand-made cases for the contradictions in the report. Each prints what the separate checker says."""
import copy
from engine import allocate, revise
import checker as ck, gen

_t = [0]
def cab(cid, size, group="", seg="", n=None, **extra):
    pairs = {}
    for p in range(1, (n or size) + 1):
        _t[0] += 1; pairs[p] = {"tag": f"T{_t[0]}", "io_type": "AI"}
    return {"id": cid, "size": size, "group": group, "segregation": seg, "extra": extra, "pairs": pairs}

def rules(K=4, P=8, spare=10, preset="Class", span="only_if_too_big", extra=(), **sp):
    rs = copy.deepcopy(gen.DEFAULT)
    c = gen.rule(rs, "capacity"); c["ciocs_per_cabinet"] = K; c["baseplates_per_cioc"] = P
    s = gen.rule(rs, "spare"); s["percent"] = spare; s.update(sp)
    gen.rule(rs, "groups")["span"] = span
    gen.set_preset(rs, preset); rs["rules"] += list(extra)
    return rs

def cabs_of(rows, cables):
    t = {s["tag"]: c["id"] for c in cables for s in c["pairs"].values()}
    out = {}
    for r in rows: out[t[r[0]]] = r[1:]            # address of the cable's last listed signal is enough to show
    first = {}
    for r in rows: first.setdefault(t[r[0]], r[1:])
    return first

print("B1  cabinet-level rule + 'open a new CIOC' (allocation.md s6, last 'if' of try_cabinet)")
rs = rules(extra=[{"id": "sis-bpcs", "type": "separate", "enabled": True, "level": "cabinet", "field": "sys", "sets": None, "blank_is_value": False}])
cs = [cab("X", 2, sys="SIS"), cab("Y", 2, sys="BPCS")]
for lit in (True, False):
    r = allocate(cs, rs, literal=lit)
    print(f"   literal={lit}: first-signal address per cable {cabs_of(r['rows'], cs)}  I5 -> {ck.check_I5(cs, r['rows'], rs)}")

print("B1b same, with a dedicated rule at cabinet level")
rs = rules(extra=[{"id": "area-cab", "type": "dedicated", "enabled": True, "level": "cabinet", "fields": ["area"], "applies_when": [{"field": "area", "op": "not_blank"}], "allow_guests": True}])
cs = [cab("X", 2, area="N"), cab("Y", 2, area="S")]
for lit in (True, False):
    r = allocate(cs, rs, literal=lit)
    print(f"   literal={lit}: {cabs_of(r['rows'], cs)}  I6 -> {ck.check_I6(cs, r['rows'], rs)}")

print("B2  spare unit 'charms': the partly-used-baseplate branch never asks budget_ok")
rs = rules(K=1, P=1, spare=50, unit="charms")
cs = [cab("X", 6), cab("Y", 2)]
for lit in (True, False):
    r = allocate(cs, rs, literal=lit)
    print(f"   literal={lit}: {cabs_of(r['rows'], cs)} unplaced={r['unplaced']} cabinets={r['cabinets']}  I8 -> {ck.check_I8(cs, r['rows'], rs)}")

print("B3  revision step 3a (old start address) for a cable that changed group -> I7 broken run")
rs = rules(K=1, P=1, spare=0)
a = [cab("X", 12, "G1"), cab("Y", 12, "G2"), cab("Z", 6, "G3")]
ra = allocate(a, rs)
b = copy.deepcopy(a); b[0]["group"] = "G3"
for lit in (True, False):
    r = revise(a, ra["rows"], b, rs, literal=lit)
    print(f"   literal={lit}: {cabs_of(r['rows'], b)} unplaced={r['unplaced']}  I7 -> {ck.check_I7(b, r['rows'], rs, False)[0]}")

print("B4  'Deleted cables free their slots. The holes stay.' vs I7 'one unbroken run'")
a = [cab("X", 12, "G1"), cab("Y", 12, "G1"), cab("Z", 12, "G1")]
ra = allocate(a, rs)
b = [copy.deepcopy(a[0]), copy.deepcopy(a[2])]
for lit in (True, False):
    r = revise(a, ra["rows"], b, rs, literal=lit)
    print(f"   literal={lit}: Rev A {cabs_of(ra['rows'], a)}  Rev B {cabs_of(r['rows'], b)}  I7 -> {ck.check_I7(b, r['rows'], rs, False)[0]}")

print("B4b same effect when the middle cable only changes group (nothing deleted)")
b = copy.deepcopy(a); b[1]["group"] = "G9"
r = revise(a, ra["rows"], b, rs)
print(f"   Rev B {cabs_of(r['rows'], b)}  I7 -> {ck.check_I7(b, r['rows'], rs, False)[0]}")

print("B5  a cable grows: s10 says re-place it, I11 says its signals may not move (default rules)")
rs = rules()
a = [cab("X", 6, "G1", "A"), cab("Y", 6, "G1", "A")]
ra = allocate(a, rs)
b = copy.deepcopy(a); b[0]["size"] = 12
r = revise(a, ra["rows"], b, rs)
print(f"   Rev A {cabs_of(ra['rows'], a)}  Rev B {cabs_of(r['rows'], b)}")
print(f"   I11 as written -> {ck.check_I11(a, ra['rows'], b, r['rows'], rs)[:2]} ...")
print(f"   I11 with 'and same size' -> {ck.check_I11(a, ra['rows'], b, r['rows'], rs, True)}")

print("B6  revision step 3c with span=never -> group in two cabinets")
rs = rules(K=1, P=1, spare=0, span="never")
a = [cab("X", 12, "G1")]
ra = allocate(a, rs)
b = copy.deepcopy(a) + [cab("N", 2, "G1")]
for lit in (True, False):
    r = revise(a, ra["rows"], b, rs, literal=lit)
    print(f"   literal={lit}: {cabs_of(r['rows'], b)} unplaced={r['unplaced']}  I7 never -> {ck.check_I7(b, r['rows'], rs, False)[1]}")

print("B7  span=never: R01 for a group that is not too big (4 classes, 4 CIOCs, but one CIOC is used)")
rs = rules(span="never")
cs = [cab("P", 2, "G1", "A"), cab("Q", 2, "G2", "A"), cab("R", 2, "G2", "B"), cab("S", 2, "G2", ""), cab("U", 2, "G2", "C")]
r = allocate(cs, rs)
print(f"   {cabs_of(r['rows'], cs)} unplaced={r['unplaced']} cabinets={r['cabinets']}")
rs3 = rules(K=3, span="never")
cs = [cab("Q", 2, "G2", "A"), cab("R", 2, "G2", "B"), cab("S", 2, "G2", ""), cab("U", 2, "G2", "C")]
r = allocate(cs, rs3)
print(f"   K=3, one group, 4 classes, 8 pairs in total: unplaced={r['unplaced']}")

print("B8  I4 as written passes overlapping footprints when the overlap is on unused pairs")
rs = rules()
cs = [cab("X", 6, n=2), cab("Y", 6)]
for p in (1, 2, 3, 4): del cs[1]["pairs"][p]          # Y has signals on pairs 5,6 only
rows = [(cs[0]["pairs"][1]["tag"], 1, 1, 1, 1), (cs[0]["pairs"][2]["tag"], 1, 1, 1, 2),
        (cs[1]["pairs"][5]["tag"], 1, 1, 1, 7), (cs[1]["pairs"][6]["tag"], 1, 1, 1, 8)]
print("   X owns slots 1-6, Y (pair 5 at slot 7) owns slots 3-8. No signal of one is inside the other's footprint.")
print("   my I4 (footprint overlap added) ->", ck.check_I4(cs, rows, rs), "| I2 ->", ck.check_I2(rows))

print("B9  judge example 'DO-SOV never shares a baseplate with AI' on one mixed cable -> D09, never placed")
rs = rules(extra=[{"id": "sov-ai", "type": "separate", "enabled": True, "level": "baseplate", "field": "io_type", "sets": [["DO-SOV"], ["AI"]], "blank_is_value": False}])
c = cab("X", 6); c["pairs"][3]["io_type"] = "DO-SOV"
r = allocate([c], rs); print("   unplaced:", r["unplaced"])

print("B10 nearest rounding at a half: 25% of 42 baseplates (K=6, P=7) = 10.5")
print("   half-up ->", ck._res(25, 42, "nearest"), "; Python round() ->", round(0.25 * 42), "; float 0.1*30 =", 0.1 * 30, "-> ceil 4, exact 3")
