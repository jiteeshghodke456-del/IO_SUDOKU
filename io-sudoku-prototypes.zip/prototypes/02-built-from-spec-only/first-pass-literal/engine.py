"""Prototype engine written ONLY from allocation.md s3-7, s10 and rules.md s3-4.
Every guess is marked GUESS(n) and listed in the report.
literal=True follows the pseudo-code word for word where a guess was needed to keep invariants.
"""
import math, re
from fractions import Fraction

GUEST = ("<guest>",)


def natkey(v):
    s = "" if v is None else str(v)
    parts = tuple((0, int(p), "") if p.isdigit() else (1, 0, p) for p in re.split(r"(\d+)", s) if p != "")
    return (parts, s)                       # GUESS: raw string breaks natural ties ("G2" vs "G02")


def is_blank(v):
    return v is None or str(v).strip() == ""


def sig_field(cable, pair, sig, field):
    if field == "tag": return sig["tag"]
    if field == "io_type": return sig["io_type"]
    if field == "cable": return cable["id"]
    if field == "pair": return pair
    if field == "cable_size": return cable["size"]
    ex = sig.get("extra") or {}
    if field in ex: return ex[field]
    if field in ("group", "segregation"): return cable.get(field) or ""
    return (cable.get("extra") or {}).get(field, "")


def sel_match(conds, get):
    for c in conds:
        v = get(c["field"]); op = c["op"]; x = c.get("value")
        sv = "" if v is None else str(v)
        if op == "eq": ok = sv == str(x)
        elif op == "ne": ok = sv != str(x)
        elif op == "in": ok = sv in [str(i) for i in x]
        elif op == "not_in": ok = sv not in [str(i) for i in x]
        elif op == "contains": ok = str(x) in sv
        elif op == "startswith": ok = sv.startswith(str(x))
        elif op == "regex": ok = re.search(x, sv) is not None
        elif op == "blank": ok = is_blank(v)
        elif op == "not_blank": ok = not is_blank(v)
        else: raise ValueError(op)
        if not ok: return False
    return True


def reserve(percent, n, rounding):
    x = Fraction(str(percent)) * n / 100     # exact, no float (0.1*30 == 3.0000000000000004 in float)
    if rounding == "up": return math.ceil(x)
    if rounding == "down": return math.floor(x)
    return math.floor(x + Fraction(1, 2))    # GUESS: nearest = half up


class Bp:
    __slots__ = ("slots", "used", "cnt")
    def __init__(self, S): self.slots = [None] * S; self.used = 0; self.cnt = {}


class Cioc:
    __slots__ = ("bps", "used_bps", "fslots", "cnt")
    def __init__(self, S, P): self.bps = [Bp(S) for _ in range(P)]; self.used_bps = 0; self.fslots = 0; self.cnt = {}


class Cab:
    __slots__ = ("ciocs", "used_bps", "fslots", "cnt")
    def __init__(self): self.ciocs = []; self.used_bps = 0; self.fslots = 0; self.cnt = {}


class Engine:
    def __init__(self, rules, literal=False):
        self.literal = literal
        en = [r for r in rules["rules"] if r.get("enabled", True)]
        cap = [r for r in en if r["type"] == "capacity"][0]
        self.S, self.P, self.K = cap["slots_per_baseplate"], cap["baseplates_per_cioc"], cap["ciocs_per_cabinet"]
        self.max_cab = cap.get("max_cabinets")
        g = [r for r in en if r["type"] == "grouping"]
        self.grouping = g[0] if g else None
        sp = [r for r in en if r["type"] == "spare"]
        self.spare = sp[0] if sp else None
        self.preds = []
        for r in en:
            if r["type"] == "separate":
                self.preds.append(dict(id=r["id"], type="separate", level=r.get("level", "cioc"),
                                       field=r.get("field", "segregation"), sets=r.get("sets"),
                                       blank_is_value=r.get("blank_is_value", False)))
            elif r["type"] == "dedicated":
                self.preds.append(dict(id=r["id"], type="dedicated", level=r.get("level", "cioc"),
                                       fields=r.get("fields", ["group", "segregation"]),
                                       applies_when=r.get("applies_when", [{"field": "group", "op": "not_blank"}]),
                                       allow_guests=r.get("allow_guests", True)))
        self.lev = {"baseplate": [], "cioc": [], "cabinet": []}
        for i, r in enumerate(self.preds):
            r["ix"] = i
            self.lev[r["level"]].append(r)
        self.ded = [r for r in self.preds if r["type"] == "dedicated"]
        self.cabinets = []
        self.start = {}
        self.size = {}
        self.lab = {}
        self.group = {}
        self.journal = None
        self.ignore_budget = False
        self.blockers = {}
        self.cur = None

    # ---------- labels (s3)
    def label(self, cable):
        """returns list of rule ids the cable's signals disagree on (D09), stores labels"""
        cid = cable["id"]; bad = []; lab = []
        sigs = sorted(cable["pairs"].items())
        for r in self.preds:
            vals = set()
            for pair, sig in sigs:
                get = lambda f: sig_field(cable, pair, sig, f)
                if r["type"] == "separate":
                    v = get(r["field"])
                    if is_blank(v):
                        vals.add(("<blank>",) if r["blank_is_value"] else None)
                    elif r["sets"] is None:
                        vals.add(str(v))
                    else:
                        side = None                       # GUESS: value in no set = no side
                        for i, st in enumerate(r["sets"]):
                            if str(v) in [str(x) for x in st]: side = i; break
                        vals.add(side)
                else:
                    if sel_match(r["applies_when"], get):
                        vals.add(tuple(str(get(f) if not is_blank(get(f)) else "") for f in r["fields"]))
                    else:
                        vals.add(GUEST)
            if r["type"] == "separate":
                vals.discard(None)                         # GUESS: "no side" signals do not disagree with sided ones
                if len(vals) > 1: bad.append(r["id"]); lab.append(None)
                else: lab.append(next(iter(vals)) if vals else None)
            else:
                keys = vals - {GUEST}
                if len(keys) > 1 or (keys and GUEST in vals and not r["allow_guests"]):
                    bad.append(r["id"]); lab.append(None)   # GUESS: guest+keyed signals on one cable = keyed, unless guests are not allowed
                else:
                    lab.append(next(iter(keys)) if keys else GUEST)
        grp = None
        if self.grouping:
            gv = set()
            for pair, sig in sigs:
                v = sig_field(cable, pair, sig, self.grouping.get("field", "group"))
                gv.add(None if is_blank(v) else str(v))
            if len(gv) > 1: bad.append(self.grouping["id"])
            else: grp = next(iter(gv))
        self.lab[cid] = tuple(lab); self.group[cid] = grp; self.size[cid] = cable["size"]
        return bad

    def labels_of(self, cid):
        return (self.lab[cid], self.group[cid])

    # ---------- predicates (s5)
    def accepts(self, cont, level, cid):
        lab = self.lab[cid]
        for r in self.lev[level]:
            l = lab[r["ix"]]; d = cont.cnt.get(r["ix"])
            if not d: continue
            ok = True
            if r["type"] == "separate":
                if l is not None and any(k != l for k in d): ok = False
            else:
                if l == GUEST:
                    if not r["allow_guests"] and any(k != GUEST for k in d): ok = False
                else:
                    if any(k != GUEST and k != l for k in d): ok = False
                    elif not r["allow_guests"] and GUEST in d: ok = False
            if not ok:
                if self.cur is not None: self.blockers.setdefault(self.cur, set()).add(r["id"])
                return False
        return True

    def budget_ok(self, cab, cioc, new_bps, new_slots):
        sp = self.spare
        if sp is None or self.ignore_budget: return True
        S, P, K = self.S, self.P, self.K
        rnd = sp.get("rounding", "up"); pct = sp.get("percent", 10)
        if sp.get("unit", "baseplates") == "baseplates":
            if sp.get("per", "cabinet") == "cabinet":
                ok = cab.used_bps + new_bps <= K * P - reserve(pct, K * P, rnd)
            else:
                ok = (cioc.used_bps if cioc else 0) + new_bps <= P - reserve(pct, P, rnd)
        else:
            if sp.get("per", "cabinet") == "cabinet":
                ok = cab.fslots + new_slots <= K * P * S - reserve(pct, K * P * S, rnd)
            else:
                ok = (cioc.fslots if cioc else 0) + new_slots <= P * S - reserve(pct, P * S, rnd)
        if not ok and self.cur is not None: self.blockers.setdefault(self.cur, set()).add(sp["id"])
        return ok

    # ---------- state changes
    def _addlab(self, cont, level, cid, d):
        lab = self.lab[cid]
        for r in self.lev[level]:
            l = lab[r["ix"]]
            if l is None: continue
            m = cont.cnt.setdefault(r["ix"], {})
            m[l] = m.get(l, 0) + d
            if m[l] == 0: del m[l]

    def _put(self, cid, c, k, b, s):
        S = self.S; cab = self.cabinets[c]; cioc = cab.ciocs[k]; n = self.size[cid]
        p0 = b * S + s
        for bi in range(b, (p0 + n - 1) // S + 1):
            bp = cioc.bps[bi]
            if bp.used == 0: cioc.used_bps += 1; cab.used_bps += 1
            lo = max(p0, bi * S); hi = min(p0 + n, (bi + 1) * S)
            for pos in range(lo, hi):
                assert bp.slots[pos - bi * S] is None
                bp.slots[pos - bi * S] = cid
            bp.used += hi - lo
            self._addlab(bp, "baseplate", cid, 1)
        cioc.fslots += n; cab.fslots += n
        self._addlab(cioc, "cioc", cid, 1); self._addlab(cab, "cabinet", cid, 1)
        self.start[cid] = (c, k, b, s)
        if self.journal is not None: self.journal.append(("put", cid))

    def _remove(self, cid):
        S = self.S; c, k, b, s = self.start.pop(cid); cab = self.cabinets[c]; cioc = cab.ciocs[k]; n = self.size[cid]
        p0 = b * S + s
        for bi in range(b, (p0 + n - 1) // S + 1):
            bp = cioc.bps[bi]
            lo = max(p0, bi * S); hi = min(p0 + n, (bi + 1) * S)
            for pos in range(lo, hi): bp.slots[pos - bi * S] = None
            bp.used -= hi - lo
            if bp.used == 0: cioc.used_bps -= 1; cab.used_bps -= 1
            self._addlab(bp, "baseplate", cid, -1)
        cioc.fslots -= n; cab.fslots -= n
        self._addlab(cioc, "cioc", cid, -1); self._addlab(cab, "cabinet", cid, -1)

    def _open_cioc(self, c):
        self.cabinets[c].ciocs.append(Cioc(self.S, self.P))
        if self.journal is not None: self.journal.append(("cioc", c))

    def _open_cab(self):
        self.cabinets.append(Cab())
        if self.journal is not None: self.journal.append(("cab",))

    def undo(self, journal):
        for e in reversed(journal):
            if e[0] == "put": self._remove(e[1])
            elif e[0] == "cioc": self.cabinets[e[1]].ciocs.pop()
            else: self.cabinets.pop()

    # ---------- the one primitive (s6)
    def try_cabinet(self, cid, c):
        S, P, K = self.S, self.P, self.K
        cab = self.cabinets[c]; n = self.size[cid]; m = -(-n // S)
        cab_ok = self.accepts(cab, "cabinet", cid)
        for k, cioc in enumerate(cab.ciocs):
            if not cab_ok or not self.accepts(cioc, "cioc", cid): continue
            if n <= S:
                for b, bp in enumerate(cioc.bps):
                    if 0 < bp.used and bp.used + n <= S and self.accepts(bp, "baseplate", cid):
                        run = 0; at = None
                        for i, v in enumerate(bp.slots):
                            run = run + 1 if v is None else 0
                            if run == n: at = i - n + 1; break
                        if at is not None:
                            # GUESS: with unit=charms the budget must be asked here too; the pseudo-code does not
                            if self.literal or self.budget_ok(cab, cioc, 0, n):
                                self._put(cid, c, k, b, at); return True
            if m <= P and self.budget_ok(cab, cioc, m, n):
                run = 0
                for b, bp in enumerate(cioc.bps):
                    run = run + 1 if bp.used == 0 else 0
                    if run == m:
                        self._put(cid, c, k, b - m + 1, 0); return True
        # GUESS: cabinet-level accepts must also hold before opening a new CIOC; the pseudo-code does not ask
        if len(cab.ciocs) < K and (self.literal or cab_ok) and m <= P and self.budget_ok(cab, None, m, n):
            self._open_cioc(c)
            self._put(cid, c, len(cab.ciocs) - 1, 0, 0); return True
        return False

    def place(self, cid, cabs, may_open):
        """returns True, or a TQ code"""
        self.cur = cid
        for c in cabs:
            if self.try_cabinet(cid, c): return True
        if may_open:
            if self.max_cab is not None and len(self.cabinets) >= self.max_cab: return "C02"
            self._open_cab()
            if self.try_cabinet(cid, len(self.cabinets) - 1): return True
            self.cabinets.pop()                      # GUESS: an opened cabinet that could not take the cable is closed again
            if self.journal is not None: self.journal.pop()
        return "C01"

    def try_address(self, cid, c, k, b, s):
        """s10 step 3a. Not expressible with try_cabinet; GUESS at its checks."""
        S, P = self.S, self.P; n = self.size[cid]
        if c >= len(self.cabinets) or k >= len(self.cabinets[c].ciocs): return False
        cab = self.cabinets[c]; cioc = cab.ciocs[k]; p0 = b * S + s
        if n <= S:
            if s + n > S: return False
        elif s != 0: return False
        if p0 + n > P * S: return False
        self.cur = cid
        if not self.accepts(cab, "cabinet", cid) or not self.accepts(cioc, "cioc", cid): return False
        new_bps = 0
        for bi in range(b, (p0 + n - 1) // S + 1):
            bp = cioc.bps[bi]
            lo = max(p0, bi * S); hi = min(p0 + n, (bi + 1) * S)
            if any(bp.slots[pos - bi * S] is not None for pos in range(lo, hi)): return False
            if not self.accepts(bp, "baseplate", cid): return False
            if bp.used == 0: new_bps += 1
        if not self.budget_ok(cab, cioc, new_bps, n): return False
        self._put(cid, c, k, b, s); return True

    def dedkey(self, cid):
        # GUESS: with several dedicated rules, sort on all of them in rule-list order; guests last; natural order per field
        out = []
        for r in self.ded:
            l = self.lab[cid][r["ix"]]
            out.append((1,) if l == GUEST else (0, tuple(natkey(x) for x in l)))
        return tuple(out)

    def rows(self, cables):
        S = self.S; out = []
        for cable in cables:
            st = self.start.get(cable["id"])
            if st is None: continue
            c, k, b, s = st
            for pair, sig in cable["pairs"].items():
                pos = b * S + s + pair - 1
                out.append((sig["tag"], c + 1, k + 1, pos // S + 1, pos % S + 1))
        out.sort(key=lambda r: (r[1], r[2], r[3], r[4]))
        return out


def _finish(eng, cables, unplaced):
    rows = eng.rows(cables)
    tq = []
    for cable in cables:
        if cable["id"] in unplaced:
            for pair, sig in sorted(cable["pairs"].items()):
                tq.append((sig["tag"], unplaced[cable["id"]]))
    return dict(rows=rows, tq=tq, unplaced=dict(unplaced), cabinets=len(eng.cabinets),
                blockers={k: sorted(v) for k, v in eng.blockers.items() if k in unplaced})


def allocate(cables, rules, literal=False):
    """Base allocation, s7."""
    eng = Engine(rules, literal)
    cables = sorted(cables, key=lambda c: natkey(c["id"]))
    unplaced = {}; groups = {}; blank = []
    for cable in cables:
        if eng.label(cable): unplaced[cable["id"]] = "D09"; continue
        g = eng.group[cable["id"]]
        (blank if g is None else groups.setdefault(g, [])).append(cable["id"])
    gr = eng.grouping or {}
    span = gr.get("span", "only_if_too_big"); order = gr.get("order", "natural"); bl = gr.get("blank", "fill_free_slots")
    if order == "size_desc":
        # GUESS: group size = sum of cable sizes of every input cable in the group; ties natural
        gsz = {}
        for cable in cables:
            for pair, sig in cable["pairs"].items():
                v = sig_field(cable, pair, sig, gr.get("field", "group")); break
            if not is_blank(v): gsz[str(v)] = gsz.get(str(v), 0) + cable["size"]
        gorder = sorted(groups, key=lambda g: (-gsz.get(g, 0), natkey(g)))
    else:
        gorder = sorted(groups, key=natkey)          # "free" (P1) not built: natural
    current = [None]

    def do_group(cids, span):
        cg = sorted(cids, key=lambda i: (eng.dedkey(i), -eng.size[i], natkey(i)))
        placed = False
        if span in ("only_if_too_big", "never"):
            if current[0] is not None:
                eng.journal = []; placed = True
                for i in cg:
                    if eng.place(i, [current[0]], False) is not True:
                        eng.undo(eng.journal); placed = False; break
                eng.journal = None
            if not placed and (eng.max_cab is None or len(eng.cabinets) < eng.max_cab):
                eng.journal = []; eng._open_cab(); new = len(eng.cabinets) - 1; placed = True
                for i in cg:
                    if eng.place(i, [new], False) is not True:
                        eng.undo(eng.journal); placed = False; break
                eng.journal = None
        if not placed:
            if span == "never":
                for i in cg: unplaced[i] = "R01"
                return
            for i in cg:
                lo = current[0] if current[0] is not None else 0
                r = eng.place(i, range(lo, len(eng.cabinets)), True)
                if r is not True: unplaced[i] = r
        used = [eng.start[i][0] for i in cg if i in eng.start]
        if used: current[0] = max(used)            # GUESS: "last cabinet used" = highest number

    for g in gorder:
        do_group(groups[g], span)
    if bl == "place_last":
        # GUESS: the blank "group" is never refused with R01
        if blank: do_group(blank, "only_if_too_big" if span == "never" else span)
    else:
        for i in sorted(blank, key=lambda i: (-eng.size[i], natkey(i))):
            r = eng.place(i, range(len(eng.cabinets)), True)
            if r is not True: unplaced[i] = r
    return _finish(eng, cables, unplaced)


def revise(cables_a, rows_a, cables_b, rules, literal=False):
    """Revision, s10. Rules are assumed identical in both revisions (GUESS)."""
    S = Engine(rules).S
    # Rev A labels and start addresses
    ea = Engine(rules); bad_a = set()
    tagmap = {}
    for cable in cables_a:
        if ea.label(cable): bad_a.add(cable["id"])
        for pair, sig in cable["pairs"].items(): tagmap[sig["tag"]] = (cable["id"], pair)
    old = {}; ncab = 0; nci = {}
    for tag, c, k, b, s in rows_a:
        cid, pair = tagmap[tag]
        pos = (b - 1) * S + (s - 1) - (pair - 1)
        old.setdefault(cid, (c - 1, k - 1, pos // S, pos % S))
        ncab = max(ncab, c); nci[c - 1] = max(nci.get(c - 1, 0), k)
    eng = Engine(rules, literal)
    # GUESS: Rev B starts with the same cabinets and CIOCs as Rev A, even if emptied by deletions
    for c in range(ncab):
        eng._open_cab()
        for _ in range(nci.get(c, 0)): eng._open_cioc(c)
    cables_b = sorted(cables_b, key=lambda c: natkey(c["id"]))
    unplaced = {}; todo = []; gcabs = {}; stable = []
    def note(cid):
        g = eng.group[cid]
        if g is not None:
            d = gcabs.setdefault(g, {}); c = eng.start[cid][0]; d[c] = d.get(c, 0) + 1
    for cable in cables_b:
        cid = cable["id"]
        if eng.label(cable): unplaced[cid] = "D09"; continue
        if (cid in old and cid not in bad_a and ea.size[cid] == eng.size[cid]
                and ea.labels_of(cid) == eng.labels_of(cid)):
            eng._put(cid, *old[cid]); note(cid); stable.append(cid)   # step 1: no questions asked
        else:
            todo.append(cid)
    sp = eng.spare or {}
    eng.ignore_budget = bool(sp.get("revision_uses_spare", True))
    span = (eng.grouping or {}).get("span", "only_if_too_big")
    moved_reason = {}
    for cid in sorted(todo, key=lambda i: (-eng.size[i], natkey(i))):
        g = eng.group[cid]; done = False
        mine = sorted(gcabs.get(g, {})) if g is not None else []
        if cid in old:
            oc = old[cid][0]
            # GUESS (non-literal): the old address is only tried when it keeps the group's run unbroken
            allowed = (literal or g is None or not mine or oc in mine or (span != "never" and oc == mine[-1] + 1))
            if allowed and eng.try_address(cid, *old[cid]): done = True
        if not done:
            if g is None:
                r = eng.place(cid, range(len(eng.cabinets)), True)
            elif not mine:
                r = eng.place(cid, [], True)              # brand-new group: after the last cabinet
            else:
                r = eng.place(cid, mine, False)           # b
                if r is not True and (literal or span != "never"):   # GUESS: span never forbids step c
                    nxt = mine[-1] + 1
                    r = eng.place(cid, [nxt], False) if nxt < len(eng.cabinets) else eng.place(cid, [], True)
            if r is not True: unplaced[cid] = r; continue
        note(cid)
    out = _finish(eng, cables_b, unplaced); out["stable"] = stable
    return out
