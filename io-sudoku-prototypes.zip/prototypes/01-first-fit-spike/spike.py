"""Throwaway spike: does 'ordered first-fit with rule predicates' give a valid
allocation, how many cabinets, how fast, and does a revision keep unchanged
signals in place? An independent checker (separate functions, works only from
the output rows) proves the result.
"""
import math, random, re, time, sys
from collections import defaultdict
from dataclasses import dataclass, field


# ----------------------------------------------------------------- data
@dataclass
class Cable:
    id: str
    size: int
    group: str | None
    seg: str | None
    pairs: dict  # pair -> (tag, io)

    @property
    def cls(self):
        return (self.group, self.seg)


@dataclass
class Rules:
    S: int = 12
    P: int = 8
    K: int = 4
    spare_pct: float = 10
    sharing: str = "class"            # class | group | any
    ungrouped_fill: str = "any_free_slot"   # any_free_slot | own_ciocs
    unseg_may_mix: bool = True
    span: str = "only_if_too_big"     # only_if_too_big | always
    order: str = "listed"             # listed | size_desc (heuristic for free order)

    @property
    def E(self):
        return math.ceil(self.spare_pct / 100 * self.K * self.P - 1e-9)

    @property
    def U(self):
        return self.K * self.P - self.E


def natkey(s):
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", s or "~")]


def synth(n_signals, n_groups, seed=1, grouped_share=0.85):
    rnd = random.Random(seed)
    cables, sig, cid = [], 0, 0
    while sig < n_signals:
        size = rnd.choices([24, 12, 6, 2], weights=[55, 20, 15, 10])[0]
        group = f"G{rnd.randint(1, n_groups)}" if rnd.random() < grouped_share else None
        seg = rnd.choice(["A", "B", None])
        used = max(1, size - rnd.choice([0, 0, 1, 2, 2, 3]) if size > 2 else rnd.choice([1, 2]))
        io = rnd.choice(["AI", "AI", "AI", "DI", "DI", "AO", "DO", "DO-SOV"])
        cid += 1
        pairs = {p: (f"10-{io[:2]}-{cid:04d}-{p:02d}", io) for p in range(1, used + 1)}
        cables.append(Cable(f"CBL-{cid:04d}", size, group, seg, pairs))
        sig += used
    return cables


# ----------------------------------------------------------------- engine
class State:
    """cabinets -> ciocs -> baseplates -> slots (cable id or None)."""

    def __init__(self, rules):
        self.r = rules
        self.cabs = []            # each: list of ciocs; cioc = dict(bps=[[None]*S]*P, cables=set())
        self.where = {}           # cable id -> (cab, cioc, bp, slot) of pair 1 (0-based)
        self.cable = {}
        self.journal = None

    # -- helpers
    def used_bp(self, c):
        return sum(1 for cioc in self.cabs[c] for bp in cioc["bps"] if any(s is not None for s in bp))

    def cioc_ok(self, cioc, cab: Cable):
        r = self.r
        occ = [self.cable[i] for i in cioc["cables"]]
        segs = {o.seg for o in occ} | {cab.seg}
        real = {s for s in segs if s is not None}
        if len(real) > 1:
            return False
        if not r.unseg_may_mix and None in segs and real:
            return False
        grouped = [o for o in occ if o.group is not None]
        if cab.group is None:
            if r.ungrouped_fill == "own_ciocs" and grouped:
                return False
            return True
        if r.ungrouped_fill == "own_ciocs" and any(o.group is None for o in occ):
            return False
        if r.sharing == "class":
            return all(o.cls == cab.cls for o in grouped)
        if r.sharing == "group":
            return all(o.group == cab.group for o in grouped)
        return True

    def bp_ok(self, bp, cab: Cable):
        ids = {s for s in bp if s is not None}
        if not ids:
            return True
        if self.r.sharing == "any":
            return True
        return all(self.cable[i].cls == cab.cls or self.cable[i].group is None or cab.group is None for i in ids)

    def _put(self, cab: Cable, c, k, b, s):
        r = self.r
        cioc = self.cabs[c][k]
        for i in range(cab.size):
            bb, ss = b + (s + i) // r.S, (s + i) % r.S
            assert cioc["bps"][bb][ss] is None
            cioc["bps"][bb][ss] = cab.id
        cioc["cables"].add(cab.id)
        self.where[cab.id] = (c, k, b, s)
        self.cable[cab.id] = cab
        if self.journal is not None:
            self.journal.append(cab.id)

    def remove(self, cid):
        c, k, b, s = self.where.pop(cid)
        cab = self.cable[cid]
        cioc = self.cabs[c][k]
        for i in range(cab.size):
            cioc["bps"][b + (s + i) // self.r.S][(s + i) % self.r.S] = None
        cioc["cables"].discard(cid)

    def fits_at(self, cab: Cable, c, k, b, s):
        """Is this exact start legal? Used to try a cable's old address first."""
        r = self.r
        if c >= len(self.cabs) or k >= len(self.cabs[c]):
            return False
        cioc = self.cabs[c][k]
        if not self.cioc_ok(cioc, cab):
            return False
        m = math.ceil((s + cab.size) / r.S)
        if b + m > r.P or (cab.size > r.S and s != 0) or (cab.size <= r.S and s + cab.size > r.S):
            return False
        new_bp = 0
        for bb in range(b, b + m):
            bp = cioc["bps"][bb]
            if not self.bp_ok(bp, cab):
                return False
            if all(x is None for x in bp):
                new_bp += 1
        for i in range(cab.size):
            if cioc["bps"][b + (s + i) // r.S][(s + i) % r.S] is not None:
                return False
        return self.used_bp(c) + new_bp <= r.U

    def try_cab(self, cab: Cable, c):
        r = self.r
        m = math.ceil(cab.size / r.S)
        budget_left = r.U - self.used_bp(c)
        for k, cioc in enumerate(self.cabs[c]):
            if not self.cioc_ok(cioc, cab):
                continue
            if cab.size <= r.S:
                for b, bp in enumerate(cioc["bps"]):      # partly used baseplates first
                    if any(x is not None for x in bp) and self.bp_ok(bp, cab):
                        run = 0
                        for s in range(r.S):
                            run = run + 1 if bp[s] is None else 0
                            if run == cab.size:
                                self._put(cab, c, k, b, s - cab.size + 1)
                                return True
            if budget_left >= m:
                for b in range(r.P - m + 1):
                    if all(all(x is None for x in cioc["bps"][b + j]) for j in range(m)):
                        self._put(cab, c, k, b, 0)
                        return True
        if len(self.cabs[c]) < r.K and budget_left >= m and m <= r.P:
            self.cabs[c].append({"bps": [[None] * r.S for _ in range(r.P)], "cables": set()})
            self._put(cab, c, len(self.cabs[c]) - 1, 0, 0)
            return True
        return False

    def place(self, cab: Cable, start, new_ok=True, only=None):
        rng = [only] if only is not None else range(start, len(self.cabs))
        for c in rng:
            if self.try_cab(cab, c):
                return True
        if new_ok and only is None:
            m = math.ceil(cab.size / self.r.S)
            if m > self.r.P or m > self.r.U:
                return False
            self.cabs.append([])
            return self.try_cab(cab, len(self.cabs) - 1)
        return False

    def rollback(self, ids, ncabs):
        for i in ids:
            self.remove(i)
        for cab in self.cabs:
            while cab and not cab[-1]["cables"]:
                cab.pop()
        while len(self.cabs) > ncabs:
            self.cabs.pop()


def ffd_order(cables):
    seg_rank = {"A": 0, "B": 1, None: 9}
    return sorted(cables, key=lambda c: (seg_rank.get(c.seg, 5), -c.size, natkey(c.id)))


def allocate(cables, rules):
    st = State(rules)
    unplaced = []
    groups = defaultdict(list)
    for c in cables:
        groups[c.group].append(c)
    ungrouped = groups.pop(None, [])
    names = sorted(groups, key=natkey)
    if rules.order == "size_desc":
        names = sorted(groups, key=lambda g: -sum(c.size for c in groups[g]))
    cur = 0
    for g in names:
        cs = ffd_order(groups[g])
        if not st.cabs:
            st.cabs.append([])

        def attempt(only):
            st.journal = []
            n0 = len(st.cabs)
            ok = all(st.place(c, 0, new_ok=False, only=only) for c in cs)
            j, st.journal = st.journal, None
            if not ok:
                st.rollback(j, n0)
            return ok

        placed = False
        if rules.span == "only_if_too_big":
            cand = range(len(st.cabs)) if rules.order == "size_desc" else [cur]
            for c in cand:
                if attempt(c):
                    placed, cur = True, max(cur, c) if rules.order == "listed" else cur
                    break
            if not placed and st.cabs[-1]:
                st.cabs.append([])
                if attempt(len(st.cabs) - 1):
                    placed, cur = True, len(st.cabs) - 1
                else:
                    st.cabs.pop()
        if not placed:                       # too big for one cabinet: run on through consecutive cabinets
            start = cur if rules.order == "listed" else len(st.cabs) - 1
            for c in cs:
                if not st.place(c, start):
                    unplaced.append(c.id)
            cur = len(st.cabs) - 1
    for c in ffd_order(ungrouped):
        start = 0 if rules.ungrouped_fill == "any_free_slot" else max(0, len(st.cabs) - 1)
        if not st.cabs:
            st.cabs.append([])
        if not st.place(c, start):
            unplaced.append(c.id)
    return st, unplaced


def rows(st):
    out = {}
    for cid, (c, k, b, s) in st.where.items():
        cab = st.cable[cid]
        for p, (tag, io) in cab.pairs.items():
            i = s + p - 1
            out[tag] = (c + 1, k + 1, b + 1 + i // st.r.S, i % st.r.S + 1, cid, p, io)
    return out


# ----------------------------------------------------------------- revision
def revise(st_a, cables_b, rules, use_spare=True):
    import dataclasses
    if use_spare:
        rules = dataclasses.replace(rules, spare_pct=0)
    st = State(rules)
    st.cabs = [[{"bps": [[None] * rules.S for _ in range(rules.P)], "cables": set()} for _ in cab] for cab in st_a.cabs]
    old = st_a.cable
    todo, unplaced, moved = [], [], []
    group_cabs = defaultdict(set)
    for c in cables_b:                                   # stable cables keep their footprint
        o = old.get(c.id)
        if o and o.size == c.size and o.cls == c.cls and c.id in st_a.where:
            cc, k, b, s = st_a.where[c.id]
            st.cable[c.id] = c
            for i in range(c.size):
                st.cabs[cc][k]["bps"][b + (s + i) // rules.S][(s + i) % rules.S] = c.id
            st.cabs[cc][k]["cables"].add(c.id)
            st.where[c.id] = (cc, k, b, s)
            group_cabs[c.group].add(cc)
        else:
            todo.append(c)
    for c in ffd_order(todo):
        if c.id in st_a.where and st.fits_at(c, *st_a.where[c.id]):
            st._put(c, *st_a.where[c.id])                # old address still legal
            continue
        gc = group_cabs.get(c.group) if c.group else None
        ok = False
        if gc:                                           # stay inside the group's own cabinets
            for cab in range(min(gc), max(gc) + 1):
                if st.try_cab(c, cab):
                    ok = True
                    break
            if not ok and max(gc) + 1 < len(st.cabs) and st.try_cab(c, max(gc) + 1):
                ok = True
        elif c.group is None:
            ok = st.place(c, 0)
        else:                                            # a brand new group goes after everything else
            ok = st.place(c, len(st.cabs) - 1)
        if ok:
            group_cabs[c.group].add(st.where[c.id][0])
            if c.id in st_a.where:
                moved.append(c.id)
        else:
            unplaced.append(c.id)
    return st, unplaced, moved


# ----------------------------------------------------------------- independent checker
def check(out, cables, rules, unplaced):
    v = defaultdict(int)
    byc = {c.id: c for c in cables}
    slot = {}
    S = rules.S
    for tag, (c, k, b, s, cid, p, io) in out.items():
        if not (1 <= k <= rules.K and 1 <= b <= rules.P and 1 <= s <= S):
            v["bounds"] += 1
        if (c, k, b, s) in slot:
            v["two signals in one slot"] += 1
        slot[(c, k, b, s)] = tag
    want = sum(len(c.pairs) for c in cables if c.id not in unplaced)
    if len(out) != want:
        v["count"] += abs(len(out) - want)
    foot = {}
    percab = defaultdict(list)
    for tag, (c, k, b, s, cid, p, io) in out.items():
        percab[cid].append((c, k, (b - 1) * S + (s - 1), p))
    for cid, items in percab.items():
        cab = byc[cid]
        base = {(c, k, lin - (p - 1)) for c, k, lin, p in items}
        if len(base) != 1:
            v["cable not side by side in pair order"] += 1
            continue
        c, k, start = base.pop()
        if cab.size <= S and start % S + cab.size > S:
            v["small cable crosses a baseplate"] += 1
        if cab.size > S and start % S != 0:
            v["large cable not aligned"] += 1
        if start + cab.size > rules.P * S:
            v["cable leaves the CIOC"] += 1
        for i in range(cab.size):
            key = (c, k, start + i)
            if key in foot:
                v["footprints overlap"] += 1
            foot[key] = cid
    cioc_segs, cioc_cls, cab_bps, group_cabs = defaultdict(set), defaultdict(set), defaultdict(set), defaultdict(set)
    for (c, k, lin), cid in foot.items():
        cab = byc[cid]
        cioc_segs[(c, k)].add(cab.seg)
        if cab.group is not None:
            cioc_cls[(c, k)].add(cab.cls if rules.sharing == "class" else cab.group if rules.sharing == "group" else 0)
            group_cabs[cab.group].add(c)
        cab_bps[c].add((k, lin // S))
    for key, segs in cioc_segs.items():
        if len({s for s in segs if s}) > 1:
            v["A and B share a CIOC"] += 1
    for key, cl in cioc_cls.items():
        if len(cl) > 1:
            v["sharing policy"] += 1
    for c, used in cab_bps.items():
        if rules.K * rules.P - len(used) < rules.E:
            v["spare baseplates"] += 1
    for g, cs in group_cabs.items():
        if max(cs) - min(cs) + 1 != len(cs):
            v["group cabinets not consecutive"] += 1
    return dict(v)


def summary(st, rules):
    n = len(st.cabs)
    ciocs = sum(len(c) for c in st.cabs)
    used = sum(1 for c in st.cabs for k in c for bp in k["bps"] for s in bp if s is not None)
    return n, ciocs, round(100 * used / (n * rules.K * rules.P * rules.S), 1)


if __name__ == "__main__":
    for n_sig, n_grp in ((10000, 60), (10000, 12), (50000, 40)):
        cables = synth(n_sig, n_grp)
        nsig = sum(len(c.pairs) for c in cables)
        slots = sum(c.size for c in cables)
        print(f"\n== {nsig} signals, {len(cables)} cables, {slots} footprint slots, {n_grp} groups")
        lb = math.ceil(slots / (Rules().U * 12))
        print("   lower bound on cabinets from slots alone:", lb)
        for label, r in (("class / listed", Rules()), ("group / listed", Rules(sharing="group")), ("any / listed", Rules(sharing="any")),
                         ("class / size order", Rules(order="size_desc")), ("class / own ungrouped", Rules(ungrouped_fill="own_ciocs")),
                         ("class / spare 0", Rules(spare_pct=0)), ("class / K=6 P=7", Rules(K=6, P=7))):
            t = time.time()
            st, unp = allocate(cables, r)
            dt = time.time() - t
            out = rows(st)
            print(f"   {label:24s} cabinets {summary(st, r)[0]:3d}  CIOCs {summary(st, r)[1]:4d}  fill {summary(st, r)[2]:5.1f}%  "
                  f"{dt:5.2f}s  unplaced {len(unp)}  violations {check(out, cables, r, set(unp)) or 0}")
    # revision
    print("\n== revision test (10,000 signals, 12 groups, class / listed)")
    rnd = random.Random(7)
    r = Rules()
    A = synth(10000, 12)
    stA, _ = allocate(A, r)
    outA = rows(stA)
    import copy
    B = copy.deepcopy(A)
    byid = {c.id: c for c in B}
    ids = list(byid)
    for cid in rnd.sample(ids, 30):                      # delete one signal each
        c = byid[cid]
        if len(c.pairs) > 1:
            c.pairs.pop(max(c.pairs))
    added_on_spare = 0
    for cid in rnd.sample(ids, 60):                      # add a signal on a spare pair
        c = byid[cid]
        free = [p for p in range(1, c.size + 1) if p not in c.pairs]
        if free:
            c.pairs[free[0]] = (f"NEW-{cid}-{free[0]}", "DI")
            added_on_spare += 1
    for cid in rnd.sample(ids, 20):                      # IO type change
        c = byid[cid]
        p = min(c.pairs)
        c.pairs[p] = (c.pairs[p][0], "AO")
    seg_changed = rnd.sample(ids, 4)
    for cid in seg_changed:
        byid[cid].seg = "B" if byid[cid].seg != "B" else "A"
    grown = [cid for cid in rnd.sample(ids, 40) if byid[cid].size == 12][:3]
    for cid in grown:
        byid[cid].size = 24
    for cid in rnd.sample(ids, 5):                       # whole cable deleted
        B.remove(byid[cid])
    groups = sorted({c.group for c in A if c.group}, key=natkey)
    for i in range(12):                                  # new cables in existing groups
        size = rnd.choice([24, 12, 6, 2])
        B.append(Cable(f"CBL-N{i:02d}", size, rnd.choice(groups + [None]), rnd.choice(["A", "B", None]),
                       {p: (f"ADD-{i}-{p}", "AI") for p in range(1, max(2, size - 1))}))
    t = time.time()
    stB, unp, moved = revise(stA, B, r)
    outB = rows(stB)
    import dataclasses
    r0 = dataclasses.replace(r, spare_pct=0)
    below = sum(1 for c in stB.cabs if r.K*r.P - sum(1 for k in c for bp in k['bps'] if any(x is not None for x in bp)) < r.E)
    print('   cabinets whose spare fell below the rule after Rev B:', below, 'of', len(stB.cabs))
    same = [t_ for t_ in outA if t_ in outB]
    cable_changed = set(seg_changed) | set(grown)
    stayed = sum(1 for t_ in same if outA[t_][:4] == outB[t_][:4])
    must_move = sum(1 for t_ in same if outA[t_][4] in cable_changed)
    print(f"   Rev B: +{added_on_spare} on spare pairs, 12 new cables, 4 cables change side, {len(grown)} cables grow, 5 cables deleted")
    print(f"   tags in both revisions {len(same)}; kept the same address {stayed}; on a changed cable {must_move}")
    print(f"   cables re-placed {len(moved)}; unplaced (would be a TQ) {len(unp)}: {unp}")
    print(f"   cabinets A {len(stA.cabs)} -> B {len(stB.cabs)}; violations (spare released) {check(outB, B, r0, set(unp)) or 0}; {time.time()-t:.2f}s")
    naive, _ = allocate(B, r)
    outN = rows(naive)
    print(f"   naive fresh re-run would move {sum(1 for t_ in same if t_ in outN and outA[t_][:4] != outN[t_][:4])} of {len(same)} signals")
