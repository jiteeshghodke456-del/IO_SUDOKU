"""Does a CP-SAT 'free group order' optimiser earn its place? Items = whole groups
measured alone (CIOCs, baseplates); bins = cabinets (K CIOCs, U baseplates)."""
import math, time
from collections import defaultdict
from ortools.sat.python import cp_model
import ortools
from spike import synth, Rules, allocate, State, ffd_order, natkey, summary

def measure(group_cables, r):
    st = State(r); st.cabs.append([])
    ok = all(st.place(c, 0, new_ok=False, only=0) for c in ffd_order(group_cables))
    return (len(st.cabs[0]), st.used_bp(0)) if ok else None

for n_grp in (60, 30, 12):
    for pol in ("class", "group"):
        r = Rules(sharing=pol, ungrouped_fill="own_ciocs")
        cables = synth(10000, n_grp)
        groups = defaultdict(list)
        for c in cables: groups[c.group].append(c)
        ung = groups.pop(None, [])
        items, big = {}, []
        for g, cs in groups.items():
            m = measure(cs, r)
            (items.__setitem__(g, m) if m else big.append(g))
        listed, _ = allocate([c for c in cables if c.group is not None], r)
        n_listed = len(listed.cabs)
        t = time.time()
        m = cp_model.CpModel(); B = n_listed
        x = {(g, b): m.new_bool_var("") for g in items for b in range(B)}
        y = [m.new_bool_var("") for _ in range(B)]
        for g in items: m.add_exactly_one(x[g, b] for b in range(B))
        for b in range(B):
            m.add(sum(items[g][0] * x[g, b] for g in items) <= r.K * y[b])
            m.add(sum(items[g][1] * x[g, b] for g in items) <= r.U * y[b])
            if b: m.add(y[b] <= y[b - 1])
        m.minimize(sum(y))
        s = cp_model.CpSolver(); s.parameters.num_workers = 1; s.parameters.random_seed = 1; s.parameters.max_time_in_seconds = 20
        st = s.solve(m)
        print(f"groups {n_grp:3d} policy {pol:5s}: fit-in-one-cabinet groups {len(items):3d}, oversize {len(big):2d}; "
              f"listed order {n_listed} cabinets; CP-SAT free order {int(s.objective_value)} ({s.status_name(st)}) in {time.time()-t:.2f}s; "
              f"bound by CIOCs {math.ceil(sum(v[0] for v in items.values())/r.K)}")
print("ortools", ortools.__version__)
